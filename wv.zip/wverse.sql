-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 19 May 2025, 18:55:48
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `wverse`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolgeler`
--

CREATE TABLE `bolgeler` (
  `id` int(10) NOT NULL,
  `bolge_adi` varchar(50) NOT NULL,
  `bolge_foto` varchar(100) NOT NULL,
  `blink` varchar(20) DEFAULT NULL,
  `anahtar` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `bolgeler`
--

INSERT INTO `bolgeler` (`id`, `bolge_adi`, `bolge_foto`, `blink`, `anahtar`) VALUES
(1, 'Velen', 'velen.png', 'velen.php', 1),
(2, 'Novigrad', 'novigrad.jpg', 'novigrad.php', 0),
(3, 'Skellige', 'skellige.jpg', 'skellige.php', 0),
(4, 'Kaer Morhen', 'KaerMorhen.jpg', 'kaermorhen.php', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iksirler`
--

CREATE TABLE `iksirler` (
  `iid` int(10) NOT NULL,
  `iksirad` varchar(20) NOT NULL,
  `iksirbuff` varchar(500) NOT NULL,
  `iksirfoto` varchar(20) NOT NULL,
  `iksirkategori` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `iksirler`
--

INSERT INTO `iksirler` (`iid`, `iksirad`, `iksirbuff`, `iksirfoto`, `iksirkategori`) VALUES
(1, 'Kedi İksiri', 'Görüş mesafesini +25 artırır ve karanlıkta görüş sağlar.', 'kedi.png', 1),
(2, 'Zebani Özü', ' Geralt\'ın taşıyabileceği max. ağırlığı 25 arttırır.', 'zebani.png', 1),
(3, 'Horoz Başı Özü', 'Tüm simya ürünleri ilave bir kez daha kullanılanılabilir.', 'horozbaş.png', 1),
(4, 'Kurt Adam Özü', 'Çatışma dışı zıplama ve koşma dayanıklılık harcamaz.', 'werewolf.png', 1),
(5, 'Katil Balina Özü', 'Suyun altında nefesini biraz daha uzun tutmaya yarar', 'balina.png', 1),
(6, 'Ak Raffard Özü', 'Kullanıldığında 35% can yeniler.', 'akrafard.png', 2),
(7, 'Kırlangıç İksiri ', 'Hem savaşta hemde savaş dışında yiyecekler gibi canınızı doldurur.', 'kirlangic.png', 2),
(8, 'Beyaz Bal', 'Aktif olan TÜM efektleri kaldırır.', 'beyazbal.png', 2),
(10, 'Kaynatılmış Ekimmara', 'Düşmanlara verilen hasarın 10%\'u canı tazeler.', 'ekimara.png', 2),
(11, 'Mezar Cadısı Özü', 'Öldürülen her düşman, savaş süresince Canlılık yenilenmesini hızlandırır.', 'ravhog.png', 2),
(13, 'Sarıasma kuşu ', 'Zehirlere karşı bağışıklık sağlar, zaten kan dolaşımında bulunan zehirlerin etkilerini nötralize eder.', 'sariasma.png', 4),
(14, 'Kar Fırtınası iksiri', 'Her düşman öldürdüğünde zaman 50% yavaşlar.\r\n', 'blizzerd.png', 4),
(15, 'Grifin Özü ', ' Alınan hasar dövüşün geri kalanı boyunca hasar direncini 1% arttırır.', 'grifin.png', 4);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `karakterler`
--

CREATE TABLE `karakterler` (
  `id` int(50) NOT NULL,
  `kfoto` varchar(100) DEFAULT NULL,
  `kfoto2` varchar(100) NOT NULL,
  `kad` varchar(100) DEFAULT NULL,
  `p1` varchar(1000) NOT NULL,
  `p2` varchar(1000) NOT NULL,
  `p3` varchar(1000) NOT NULL,
  `lakap` varchar(100) NOT NULL,
  `meslek` varchar(100) NOT NULL,
  `güc` varchar(100) NOT NULL,
  `irk` varchar(100) NOT NULL,
  `sehir` varchar(100) NOT NULL,
  `biyo` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `karakterler`
--

INSERT INTO `karakterler` (`id`, `kfoto`, `kfoto2`, `kad`, `p1`, `p2`, `p3`, `lakap`, `meslek`, `güc`, `irk`, `sehir`, `biyo`) VALUES
(1, 'geralt.png', 'geraltfoto.png', 'Geralt of Rivia', 'Geralt of Rivia, 13. yüzyıl boyunca aktif olan Kurt Okulu\'nun efsanevi bir Witcher\'ıydı. Büyücü Yennefer\'i sevdi, çalkantılı ilişkilerine rağmen hayatının aşkı olarak gördü ve Ciri\'nin üvey babası oldu.', '\r\nOt sınavı sırasında Geralt, witcherlara yeteneklerini veren mutajenlere karşı alışılmadık bir tolerans sergiledi. Bu yüzden Geralt, saçını beyazlaştıran ve ona diğer witcherlardan daha fazla hız, güç ve dayanıklılık vermiş olabilecek başka deneysel mutajenlere tabi tutuldu.', 'Unvanına rağmen Geralt, Rivya şehrinden gelmedi. Annesi Visenna tarafından Witcherlarla birlikte bırakıldıktan sonra, Kaedwen krallığında Kaer Morhen kalesinde büyüdü. Potansiyel müşterilere daha güvenilir görünmek için, genç Witcherlar usta Vesemir tarafından kendilerine soyadları uydurmaya teşvik edildi. Geralt ilk tercihi olarak \"Geralt Roger Eric du Haute-Bellegarde\"yi seçti, ancak bu seçim Vesemir tarafından aptalca ve gösterişçi olduğu için reddedildi, bu yüzden seçtiği isimden geriye sadece \"Geralt\" kaldı. \"Rivya\'ya Dair\" daha pratik bir alternatifti ve Geralt daha özgün görünmek için bir Rivya aksanını benimseyecek kadar ileri gitti. Daha sonra, Lyria Kraliçesi Meve onu Yaruga\'daki Köprü Savaşı\'ndaki cesaretinden dolayı şövalye ilan etti ve ona resmi \"Rivyalı\" unvanını verdi ve bu onu tatmin etti. Bu nedenle, gerçek bir şövalye oldu.', 'Beyaz Kurt<br> Gweynbleidd <br> Blaviken kasabı<br>', 'Witcher', 'Süper insan özellikleri <br> Büyü yapabilme <br>İksir yapabilme <br>Kılıç ustası', 'İnsan', 'Riviya', '\r\n<p>Geralt, büyücü Visenna\'nın ve muhtemelen savaşçı Korin\'in oğlu olarak doğdu. Doğumundan kısa bir süre sonra annesi onu Kurt Okulu ile Kaer Morhen kalesinde bıraktı. Orada, Geralt bir Witcher olmak için eğitildi.</p>\r\n\r\n<p>Çocukken, Ot Sınavına tabi tutuldu, Witcher yetenekleri kazandırmak için gereken birçok şiddetli mutasyondan sağ çıkmayı başardı. Olağandışı tolerans gösterdikten sonra Geralt, kendisine önemli ölçüde daha fazla güç, hız, dayanıklılık, dayanıklılık, iyileşme, duyular, hastalıklara ve geleneksel zehirlere karşı tam bağışıklık ve acıya karşı aşırı direnç kazandıran daha ileri deneysel mutasyonlara seçildi. Bu saçlarının beyazlamasına neden oldu ve \'Beyaz Kurt\' lakabını aldı.</p>\r\n\r\n<p>Geralt, bir baba figürü olarak gördüğü akıl hocası Vesemir tarafından eğitildi. Kısa süre sonra sınıf arkadaşı Eskel ile tanıştı ve ikisi iyi arkadaş ve kardeş kadar yakın oldular. Bir keresinde büyük bir orman yaban arısı yakalayıp bir sürahiye bağladılar. Çift, kendilerini deri'),
(2, 'ciri.png', 'zirael.png', 'Cirilla Fiona', 'Ciri olarak da bilinen Cirilla Fiona Elen Riannon, 1252 ya da 1253 yılının muhtemelen Belleteyn gününde doğdu(1 mayıs).Kraliçe Calanthe\'nin torunu, Pavetta ve Duny\'nin (Emhyr) tek kızı olarak Cintra\'nın prensesidir.', 'Geralt, Duny\'nin lanetinin kaldırılmasına yardım ettikten sonra kendisine ne istediği soruldu. Bu durum karşısında Geralt Sürpriz Yasası\'nı kullanmaya karar verdi. Duny, bu olaylar gerçekleştiği sırada Pavetta\'nın hamile olduğunu bilmiyordu.', '<h4 class=\"colordred border-bottom\">Kadim Kan</h4>Bu soy ona uzay-zamanı belli oranda hükmetmek gibi doğuştan gelen yetenekler kazandırmıştır.', 'Ciri <br>\r\nCintra\'nın Aslan Yavrusu <br>\r\nFalka <br>\r\nZireael <br>\r\nKırlangıç <br>\r\nKül rengi saçlı ', 'Withcer <br>\r\nPrenses <br>', 'Kadim kan güçleri <br>\r\nKılıç Ustası <br>\r\nBüyü <br>', 'İnsan', 'Cintra', '<p>Calanthe, danışmanı Fareçuval\'dan Geralt\'ı \r\nöldürerek Sürpriz Yasasından kurtulmak istediğini söyledi. Fareçuval yola çıkmaya hazırdı, kimse kraliçeye itiraz edemezdi. Ancak kısa bir süre sonra Calanthe verdiği emri sebebini açıklamadan geri çekti. </p>\r\n<p>\r\n Ciri büyürken, Pavetta\'nın kızına hayran olduğu ve kızından nadiren ayrıldığı dışında ailesiyle olan ilişkisi hakkında pek fazla şey bilinmemektedir. Yine de Pavetta, Calanthe\'nin gitmemeleri yönünde ısrarlarına rağmen, ailesiyle birlikte Skellige\'den Cintra\'ya yelken açmış ve Ciri\'yi gizlice geride bırakmıştır. Kısa bir süre sonra Pavetta ve Duny, Sedna Abyss civarında deniz kazasında ölürler ve Ciri 5 yaşına bile gelmeden yetim kalır. Calanthe, yeğeni Crach an Craite\'a yelken açmalarına izin verdiği için öfkelenmiş, Crach\'a her zaman Ciri\'yi koruyacağına dair kanının üzerine yemin ettirmiş ve Ciri\'nin Skellige\'ye gidişini yasaklamıştır. Yine de bu yasak, yalnızca 6 ay sürmüştür.\r\n</p>\r\n<p>\r\n Gel gelelim Ithlinne\'in Kehaneti ile müjdelenen, dünyanın sonunu getirecek olan, kadim kanı son barındıran kişi Cirilla Fiona Elen Riannon\'un ta kendisidir.\r\n</p>'),
(3, 'triss.png', 'trissfoto.png', 'Triss Merigold', 'Mariborlu Triss Merigold, 13. yüzyılın efsanevi Temeryalı büyücüsüydü. Yanlışlıkla Sodden Tepesi Savaşı sırasında öldürüldüğü düşünüldüğü için meslekdaşları tarafından Tepenin Ondördüncüsü olarak anılır ve tarihe Korkusuz Merigold olarak geçer. Kral Foltest\'in kraliyet konseyinin bir üyesi, Fercart ve Keira Metz\'in yanı sıra Büyücüler Locası\'nın kurucu üyesi, hayatının büyük bir bölümünde siyasete karıştı.', 'Yennefer ve Witcher Rivialı Geralt ile arkadaştı, ama aynı zamanda ikincisine de mutsuz bir şekilde aşıktı. Triss, bir süre Kaer Morhen\'de Ciri\'ye baktı ve onun ablası gibiydi. Onun müdahalesi sayesinde Ciri, Kaer Morhen\'de zararlı hormon değişikliklerine maruz kalmadı.', '\r\nYetenekli bir şifacıydı ve yanında birçok sihirli iksir taşıyordu ama onları asla kendi üzerinde kullanmadı çünkü ironik bir şekilde iksirlere alerjisi vardı ve kendini tedavi etmek için tılsımlar kullanıyordu. Aynı zamanda oldukça güçlü bir büyücüydü.', 'Tepenin Ondördüncüsü <br> Korkusuz Merigold', 'Büyücü', 'Simya <br> Büyü', 'İnsan', 'Tamerya', 'Maribor\'da bir çocuk olarak doğdu ve yaşadı. Çocukluğunda bir ara, bir değişim anı yaşadı ve büyücüler tarafından fark edildi. Böylece Aretuza\'ya giden yolu buldu. Burada, esas olarak şifa verenler olmak üzere büyülü iksirler yapımında uzmanlaşmış, kendi başına bir büyücü oldu. Bu, kaderin gülünç bir cilvesiydi, çünkü kendisinin sihirli iksirlere alerjisi vardı ve sadece sihirli olmayanlara tahammül edebiliyordu.\r\n'),
(4, 'yennefer.png', 'yennam.png', 'Yennefer', '1173 yılında,Belleteyn zamanı,Aedirn\'in başkenti Vengerberg\'de doğan Yennefer doğuştan kambur biriydi. Babası bu deformasyonu nedeniyle ondan hep nefret etti ve bu deformasyonun nedeninin insan-elf kanının karışımı olduğunu iddia edip annesini suçladı(Yennefer çeyrek elfti,annesi de yarı elf)Aynı zamanda bu dönemlerinde ismi Jenny\'di sahire olduktan sonra Yennefer kimliğiyle hayatına devam etti. Yennefer,babası tarafından uzun süre  psikolojik ve fiziksel istismara maruz kaldıktan sonra babası birgün annesini ve onu bir başkası için terk etmiş,bu olaydan sonra kızını korumaya çalışan annesi de onu dövmeye başlamıştır.', 'bir noktada,büyülü potansiyeli nedeniyle,Rektör Tissaia De Vries sahireler için öğretmen ve anne figürü olduğu Aretuza Akademisine alındı. Yennefer,Aretuza Akademisine kabulünden kısa süre sonra intihar etmeye çalıştı. Onu intihara sürükleyen şey ise şüphesiz travmatik çocukluğuydu. Kız bileklerini kesmeye çalışmıştı ama tendonlarına ciddi zarar vermek dışında başka birşey yapamadı. Ancak herşeye rağmen Rektör Tissaia De Vries tarafından el üstünde tutuluyordu. Deformasyonları ve tendon travması ilk senesi sırasında kuvvetli büyülerle örtüldü ve eğitiminin devamında kararlılığı ve sınavlardan aldığı sonuçlarla Rektör Tissaia De Vries\'ın onun hakkında düşüncelerini haklı çıkarmayı başarmıştır.', '<span></span>', 'Vengerbergli Yennefer <br>Janka <br>Jenny <br>Yen <br>Yenna <br>Savaşın Kadın Atlıs', 'Danışmanlık <br>Büyücü <br>', 'Büyü', 'Çeyrek Elf', 'Vengerberg', '<h3 class=\"border-bottom text-left colordred\">Geralt ile tanışma</h3>Geralt ve Dandelion balık tutmak isterken bir cin şişesi bulmuşlardı. Geralt, bunun tehlikeli olduğunu söyleyip şişeyi yeniden suya atmak istese de, Dandelion buna izin vermedi ve karmaşa sırasında yere düşen şişenin içinden bir cinnis çıktı ve Dandelion Dileklerini sıralamaya başladı. İlk dileği Valdo Marx\'ın çarpılmasıydı, ikinci dileği ise Caelf\'de yaşayan Kont kızı Virginia\'nın kendisine yanaşmasıydı. Ancak ozan üçüncü dileğini dileyemeden cinnis sinirlendi ve ozanın boğazını sıkmaya başladı. Geralt, Cinnis\'i kovduğu gibi boğazı şişen ve arada bir kan kusan ozan arkadaşını iyileştirecek birilerini bulmak için Rinde\'ye gitti. Fakat geceleri Rinde\'ye girmek yasaktı, kapıdaki görevliler ne kadar Dandelion\'ın durumuna acısa da mecburen Geralt ve Dandelion\'ı, Rinde\'ye gece girmek isteyenlerin bekletildiği bir yere yönlendirdiler. Burada başka insanlar gibi yaşamaya alışmış, hatta insan gibi giyinmeye başlamış efler vardı. Ozanın durumunu merak edip Geralt ile konuşmaya başlayan elfler bunun sihirli bir dokunuş olduğu kanısına vardılar. Ozanın bir daha şarkı söyleyemeyeceğini hatta konuşmasının dahi bir mucize olduğunu düşünüyorlardı. Geralt, ozanın daha da köti bir duruma sürüklendiğini düşünerek elflere Rinde\'de böyle bir hastalığı iyileştirebilecek biri olup olmadığını sordu. Elfler cevabı biliyorlardı, ama söyleyip söylememekte kararsızlardı. Redenya Kralı Heribert, büyücülük içeren her şeyi o kadar yüksek vergilere bağlamıştı ki, neredeyse bütün büyücüler kendilerini Redenya\'dan ayrılmıştı, kalanlarsa ya yeraltından iş yürütüyorlar, ya da nüfuzlu kişilerin nüfuzlu büyücüleriydi ya da bunların ikisine de sahiptiler. Vengerbergli Yennefer\'de her iki özelliği sahipti. Bir hayli ünlü, nüfuzlu bir büyücü olan Yakışıklı Berrant\'ın evinde kalıyordu.\r\n<p><br>Ertesi gün Geralt, Yakışıklı Berrant\'ın evine gidip Dandelion\'ın üzerinde ki laneti kaldırması için Vengerbergli sahireden yardım istedi. Sahire Dandelion\'ı kurtardı kurtarmasına ancak, büyünün bir cin tarafından yapıldığının da farkındaydı. Cini ehlileştirebilmek için Geralt\'ı öpücükle tılsımladı ve kasabayı karıştırıp hapse girmesine neden oldu. Ancak işler ters gidiyor, cin zayıflamıyordu. Çünkü dilek hakkı Dandelion\'ın değil Geralt\'ındı. Witcher, Yennefer\'ın yanına gitti. Büyücü ölecekti, vücudu artık dayanamıyordu. Cin, Yennefer\'a öfkelenmişti ve onu öldürmek istiyordu. Geralt, daha önceden Papaz Krepp\'in ona anlattığı gibi yaptı ve Yennefer ile kaderlerini birleştirerek onun hayatını kurtardı. Yennefer, Witcher\'a minnettardı. Witcher\'a tamamen teslim oldu ve böylece Dandelion\'ın balatlarıyla dünyaca ünlü olacak bir aşk hikayesi başladı.</p>'),
(10, '4342534641.jpg', '1018516965.png', 'Vesemir', 'Deneme için eklenmiştir', '    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid quidem repellendus, a praesentium pariatur corporis est accusantium natus laborum exercitationem odit corrupti, amet, sint minima quasi! Molestias nulla culpa porro!', '    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid quidem repellendus, a praesentium pariatur corporis est accusantium natus laborum exercitationem odit corrupti, amet, sint minima quasi! Molestias nulla culpa porro!', 'Yaşlı Kurt', 'Witcher ', 'Witcher gücleri', 'İnsan', 'Kaer Morhan', '    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid quidem repellendus, a praesentium pariatur corporis est accusantium natus laborum exercitationem odit corrupti, amet, sint minima quasi! Molestias nulla culpa porro!');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(50) NOT NULL,
  `kad` varchar(50) NOT NULL,
  `parola` varchar(20) NOT NULL,
  `yetki` tinyint(2) NOT NULL,
  `aktif` tinyint(2) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kad`, `parola`, `yetki`, `aktif`, `email`) VALUES
(2, 'admin', '12345', 1, 1, 'nebieroglu48@gmail.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kulliyat`
--

CREATE TABLE `kulliyat` (
  `id` int(10) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `katagori` int(20) NOT NULL,
  `zayıflık` varchar(1000) NOT NULL,
  `sınıf` varchar(1000) NOT NULL,
  `gy` varchar(1000) NOT NULL,
  `p1` text NOT NULL,
  `dt` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kulliyat`
--

INSERT INTO `kulliyat` (`id`, `baslik`, `foto`, `katagori`, `zayıflık`, `sınıf`, `gy`, `p1`, `dt`) VALUES
(1, 'Grifin', 'melezler8/Grifin.png', 8, '', '', '', '', ''),
(2, 'Kırkayak', 'böceksiler1/kırkayak.png', 1, 'Böcek yağı <br>Yrden', 'Böceksi', 'Toussaint', 'Toussaint dükünün büyüleyici florası ve faunası arasında, dev kırkayaklar gibi kesinlikle tatsız türden yaratıklarla da karşılaşılır. Bu canavarlar sadece göze iğrenç görünmekle kalmaz, aynı zamanda ete de muazzam zararlar verebilirler. ', 'Dev kırkayakla başa çıkmanın en iyi yolu Yrden İşareti tuzağıdır; bir tanesinin içinde yükselirse, kırkayak felç olur ve yuvaya giremez, bu da size epeyce darbe almanızı sağlar; Oradan saldırmaya karşı büyük ölçüde bağışık olduğundan, vuruşlarınızı arkaya değil öne indirdiğinizden emin olun. Birkaç kez vurulduğunda koruyucu bir döngüye dönüşecektir. Bu olduğunda yuvarlandığınızdan emin olun; Bu sadece çok az hasar vermenizi sağlayacak bir koruma hareketi değil, birkaç saniye sonra vücudunu geniş kapsamlı bir saldırıyla sallayacak ve başka bir yerde yeniden ortaya çıkmak için toprağa gömülecek.'),
(3, 'Leşen', 'direngenler2/leshen.png', 2, 'Dimerityum Bombası <br>\r\nDirengen Yağı <br>\r\nigni', 'Direngen', 'Velen <br>\r\nskellige <br>', '\r\nThe Witcher 3: Wild Hunt\'taki Leshen\'ler eski ve güçlü orman ruhlarıdır. Baş ve ağaç benzeri uzuvlar olarak bir geyik kafatasına sahip olan bir leşen, kargalardan veya bir kurt sürüsünden yardım isteyebilir.', '<p>Leshens yalnız savaşmaz. Düşmanlarının dikkatini dağıtmak ve rahatsız etmek için karga sürüleri toplayabilir ve hatta kurtları onlarla savaşmaya çağırabilirler. Geceleri ve daha karanlık yeraltı alanlarını tercih ediyor gibiler.</p>\r\n\r\n<p>Bir leshen ile karşı karşıya kaldıklarında, kök benzeri kollarını yere gömmelerini izleyin. Bu, köklere grev emri verdiklerinin bir işaretidir. Bu saldırının şaşırtıcı bir menzili var, ağır hasar veriyor, makul büyüklükte bir alana çarpıyor ve ancak oradan uzaklaşarak engellenebilir. Leshen\'ler yavaş ama güçlü yakın dövüşçülerdir ve izin verilirse ciddi yaralanmalara neden olabilir. Pençelerinin darbelerinden sıyrılın veya yuvarlanın.</p>\r\n\r\n<p>Ayrıca bir \"duman formuna\" dönüşme yeteneğine de sahiptirler; kollarını başlarının üzerine kaldıracaklar ve koyu bir duman girdabı ile gözden kaybolacaklar. Bunu yaparken, onlara yapılan herhangi bir saldırının en azından kısmen yansıtılacağını ve Quen\'i bozacağını unutmayın. Ay Tozu bombaları, hayvanat bahçesinin zayıf yönlerinden biri olarak listelememesine rağmen dönüşmelerini engelleyebilir.</p>\r\n\r\n<p>Bir dizi Hızlı Saldırıya karşı çok, çok savunmasız oldukları ve 4 veya 5 darbe aldıktan sonra mutlaka Duman formuna girecekleri görülmüştür. Bu aynı zamanda onları rastgele bir konuma ışınlayacaktır, ancak dönen küçük bir hareket eden duman bulutu olarak açıkça görülebilen duman biçiminde kalacaklar ve onlara saldırmak, ortaya çıkana kadar hiçbir zarar vermeyecektir. Duman halindeyken saldırmazlar, ancak yeniden ortaya çıktıklarında hemen yanlarında olursanız sallanırlar.</p>\r\n\r\n<p>Igni gibi potansiyel olarak yangın hasarına neden olabilecek herhangi bir bomba, leşenlere karşı faydalıdır. Bir leşen yanarken, kendini savunamayacak.</p>'),
(4, 'Zebani', 'direngenler2/zebani.png', 2, 'Şeytan puftopu <br>\r\nDirengen yağı<br>\r\nSamum <br>\r\nAard', 'Direngen', 'Velen <br>\r\nSkellige', 'The Witcher 3: Wild Hunt\'ta görünen antik bir yaratıktır. Canavar muhtemelen bir geyiği andırıyor ama boyutu daha çok bir ahırı andırıyor. İblislerin ayrıca rakiplerini hipnotize etmek için kullandıkları üçüncü bir gözü vardır.', '<p>Bir iblisi bir akort gibi düşünün: inanılmaz hız, güç ve kararlı bir öldürme arzusu, sadece daha vahşi, daha büyük ve daha öfkeli. Hemen hemen aynı şekilde savaşırlar ve benzer şekillerde yararlanılabilirler.</p>\r\n\r\n<p>İblisin üçüncü gözü, bu canavarı hesaba katılması gereken bir güç olarak tanımlar. Kurbanları tek gördükleri karanlıkta parlayan üçüncü göz olduğu bir hipnoz durumuna çekebilir. Deneyimsiz avcılar takip eden saniyeler içinde ölecekler. Witcher\'lar o yanan gözü takip etmeyi biliyorlar ve bunu tam olarak ne zaman kaçacaklarına karar vermek için kullanmayı biliyorlar.</p>\r\n\r\n<p>Hipnoz girişiminde bulunan bir iblis işaretlerle durdurulabilir, ancak kılıç darbeleriyle durdurulamaz. İyi zamanlanmış bir samum bombası, iblisin üçüncü gözünü kalıcı olarak devre dışı bırakabilir ve herhangi bir hipnoz kullanımını engelleyebilir. Aksi takdirde, hipnoz etkisinin sınırlı bir aralığı vardır; hareket için yüklenmeye başladığında (çömelmiş ve yer hafifçe sallanıyor) en az iki rulo değerinde mesafeyi geri alıyor ve etkiyi kaçırıyor. Üçüncü gözden kaçınmanın en iyi yolu, iblisin arkasına geçmek veya yanına gitmektir, çünkü hipnoz yalnızca witcher üçüncü gözü görüyorsa işe yarar. İblisler, normal ateş saldırılarına karşı özellikle savunmasız değildir, ancak Igni\'nin piromanyak ve ateş akışı, yakma etkileri veya dans eden yıldız gibi diğer yakma efektli bombalar nedeniyle çok etkilidir. Gelişmiş Kedi veya Üstün Kedi iksiri içmenin üçüncü göz saldırısına karşı tam bağışıklık kazandırarak onu işe yaramaz hale getirdiğini unutmayın.</p>\r\n\r\n<p>Saldırı tarzı açısından, daha uzun menzilde, iblis bazen yere pençe atacak ve ardından bir boğa gibi uzun menzilli bir hücum yapacak. Açmak veya iyi yerleştirilmiş atlatmak veya hasarı geçersiz kılmak için quen kullanmak seçeneklerinizdir. Daha yakın mesafeden pençeleri ve boynuzları ile orta büyüklükteki süpürme saldırılarında saldırır; neredeyse arkasından arkadan vuran birine karşı koymakta pek iyi değil.</p>'),
(5, 'Basilisk', 'drakonoidler3/basilisk.png', 3, 'Sarı asma iksiri <br>\r\nŞarapnel <br>\r\nDans eden yıldız <br>\r\nDrakonoid Yağı <br>\r\nAard', 'Drakonoid', 'Velen', 'Sanılanın aksine bakışlarıyla hiçbir şeyi taşa çeviremezler. Ancak asitleri, zehirleri, pençeleri ve dişleri onlara öldürmenin başka yollarını sağladığı için bu küçük bir problem.', '<p>Görünüşlerine rağmen, basiliskler Igni\'ye ve Dans Eden yıldız bombaları gibi onlara karşı ateş kullanmanın diğer yollarına karşı savunmasızdır. İyi zamanlanmış bir bomba veya Igni patlaması, yalnızca uçan bir basilisk\'i yer seviyesine indirmekle kalmaz, aynı zamanda canavarın kendisini gerektiği gibi savunmasını da engeller. Kanatlarını ve ayaklarındaki pençeleri cockatrice\'e benzer bir şekilde kullanma konusunda yeteneklidirler.</p>\r\n\r\n<p>Witcher\'larla savaşırken, kanatlarıyla kılıç darbelerini savuşturdukları ve sonra havaya sıçrayarak pençeleriyle yıkıcı üstten darbelerin yanına indikleri gözlemlendi. Ayrıca havaya sıçrayabilir, bir an havada kalabilir ve rakibine yukarıdan asit tükürebilir</p>'),
(6, 'Slyzard (şahmeran)', 'drakonoidler3/maderşah.png', 3, 'Şarapnel <br>\r\nDrakonoid Yağı <br>\r\nAard <br\r\nQuenn', 'Drakonoid', 'Toussaint', 'Slyzard\'lar genellikle wyverns veya çatal kuyruklularla karıştırılır. Yine de hata yapmayın: slyzardlar iğrenç, çok tehlikeli hayvanlardır ve onları wyverns için karıştırmanın sonu kafa karıştırıcı için çok kötü olacaktır. Bir wyvern, eğitimsiz bir adamı saniyeler içinde parçalara ayırabilir ve yutabilirken, yalnızca bir slyzard, ateşli bir nefes esintisiyle onu önce kıtır kıtır haline getirebilir.', '\r\n<p>Slyzardlar, saldırılarından birinden kaçtıktan ve onları cezalandırdıktan sonra sersemletmeden etkilenmedikleri için benzersiz ejderanlardır. Buna uyum sağlamak için, tek bir vuruştan kaçmak ve inmek arasında geçiş yapın. Kenara kaçın, bir kez vurun, sonra karşı saldırıya hazırlanın ve döngüyü tekrarlayın. Slyzard\'ın arkasına ya da yanına gitmek güvenliğinizi garanti etmez, çünkü slyzard kuyruğunun bir kırbacı ile onun arkasına çarpabilir. Bazen slyzard ateş püskürterek saldırır, bu da onu bir süreliğine bir animasyona kilitler, bu da iki hatta üç misilleme saldırısına izin verebilir. Yakındaysanız bir atılma ile kolayca atlatılır, ancak sizi uzaktan hazırlıksız yakalayabilir, bu nedenle yakın muharebe menziline girmediyseniz, ateş saldırısına karşı dikkatli olun.</p>\r\n\r\n<p>Tatar yayından hızlı otomatik nişan alma ile gökyüzüne kaçma girişimlerini önleyin. Slyzard, havalanırken dümdüz geriye doğru uçacak, böylece onu geri düşürmek için yalnızca Geralt\'ın amacına güvenebilirsiniz. Uçmayı başarırsa, size dalmasını ve otomatik nişan almalı bir okla vurmasını bekleyebilir veya yandan uçarken onu vurmak için manuel olarak nişan alabilirsiniz. Dikkat edilmesi gereken en önemli şey, havadan ateş topu saldırısıdır. Ağzı yakından izleyin ve orada alev toplandığını görürseniz yuvarlanmaya hazırlanın. Ateş topunun yarattığı etki alanı, yuvarlanma yenilmezliğinizi göz ardı edebileceğinden, erken yuvarlanmak isteyeceksiniz, bu nedenle erken yuvarlanmak, yenilmezlik çerçevelerine ihtiyaç duymadan sizi patlayıcı menzilin dışına çıkarmalıdır.</p>'),
(7, 'Golem', 'elementalar4/golem.png', 4, 'Dimerityum bombası <br> Elementa yağı', 'Elementa', 'Mağaralar', 'Golemler, bir büyüyle hayata geçirilen akılsız maddelerdir. Yaratıcılarının emirlerine sorgusuz sualsiz itaat ederler. Sınırsız güçleri, acıya dayanma yetenekleri, sonsuz sabırları ve en ufak bir yiyeceğe veya içeceğe ihtiyaçları olmaması, onları herkesin isteyebileceği en iyi hizmetkarlar veya muhafızlar yapar. <br>Bir kez kışkırtıldıklarında, rakiplerini ezene ya da kendilerini toza çevirene kadar savaştan yorulmazlar. Bir golemi yenmek olağanüstü zordur: bariz nedenlerden dolayı kanamaz, korku veya merhamet hissetmez ve ateşe ve zehire karşı savunmasızdır. Dahası, bir golemin vücudu bazen içinden çıkarıldığı kaya kadar serttir, bu nedenle gümüş bir bıçak bile onu zar zor yaralar. Canavarın tek zayıflığı asittir - buruk yağla kaplı bir bıçak bu nedenle kişinin zafer şansını artırabilir. Golemler silah kullanmazlar, çünkü ihtiyaçları yoktur - her biri yüz pounddan fazla olan yumrukları tek vuruşta katı graniti ezebilir. Bu nedenle, bir golemin darbesinden ne pahasına olursa olsun kaçınılmalıdır - onu durdurabilecek hiçbir kalkan ya da onu savuşturabilecek bir kılıç yoktur. Bu kolay bir iş değil, çünkü bu yaratıklar şaşırtıcı bir hızla hareket edebiliyorlar. Neyse ki, muazzam kütleleri çok çevik olmadıkları anlamına gelir - bir golem bir kez hücum etmeye başladığında, hızlı bir şekilde duramaz, deneyimli witcherların kendi avantajlarına kullandığı bir gerçektir.', ' Bir golem tarafından verilen yumrukları savuşturmaya çalışmayın. Arkalarındaki saf ağırlık ve güç, bu tür düşünmeyi en iyi ihtimalle intihara benzetiyor. Hücum eden bir golem kolayca durdurulamaz, ancak akıllı bir witcher bunu kendi avantajlarına kullanabilir. Golemin yolundan çıkın, sonra saldırın.'),
(8, 'Banshe', 'hayaletler5/banshee.png', 5, '', '', '', '', ''),
(9, 'Panter', 'hayvanlar6/panter.png', 6, '', '', '', '', ''),
(10, 'Kurt Adam', 'lanetliler7/kurtadam.png', 7, '', '', '', '', ''),
(12, 'Su Cadısı', 'nekrofagiler9/sucadısı.png', 9, '', '', '', '', ''),
(13, 'Buz Devi', 'ogroidler10/buzdevi.png', 10, '', '', '', '', ''),
(14, 'Golyat', 'ogroidler10/golyat.png', 10, '', '', '', '', ''),
(15, 'Kaya Trolü', 'ogroidler10/kayatrol.png', 10, '', '', '', '', ''),
(16, 'Tek Göz', 'ogroidler10/tekgöz.png', 10, '', '', '', '', ''),
(17, 'Yüksek Vampir', 'vampir11/highvampir.png', 11, '', '', '', '', ''),
(18, 'Protofleder', 'vampir11/protofleder.png', 11, '', '', '', '', ''),
(19, 'Ekimmara', 'vampir11/ekimmara.png', 11, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `rehber`
--

CREATE TABLE `rehber` (
  `id` int(10) NOT NULL,
  `rbaslik` varchar(100) NOT NULL,
  `rfoto` varchar(100) NOT NULL,
  `rvideo` varchar(100) NOT NULL,
  `rlink` varchar(50) DEFAULT NULL,
  `anahtar` tinyint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `rehber`
--

INSERT INTO `rehber` (`id`, `rbaslik`, `rfoto`, `rvideo`, `rlink`, `anahtar`) VALUES
(1, 'Simya', 'alchemy.jpg', 'alchemy.mp4', 'alchemy.php', 1),
(2, 'Dövüş', 'fight.jpg', 'fight.mp4', 'fight.php', 1),
(3, 'Canavar Avı', 'monsterf.jpg', 'monsterf.mp4', 'monsterf.php', 1),
(4, 'İşaretler', 'signs.jpg', 'signs.mp4', 'signs.php', 1);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `bolgeler`
--
ALTER TABLE `bolgeler`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bolge_adi` (`bolge_adi`),
  ADD UNIQUE KEY `blink` (`blink`);

--
-- Tablo için indeksler `iksirler`
--
ALTER TABLE `iksirler`
  ADD PRIMARY KEY (`iid`),
  ADD UNIQUE KEY `iksirad` (`iksirad`),
  ADD UNIQUE KEY `iksirbuff` (`iksirbuff`),
  ADD UNIQUE KEY `iksirfoto` (`iksirfoto`);

--
-- Tablo için indeksler `karakterler`
--
ALTER TABLE `karakterler`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`kad`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kad` (`kad`);

--
-- Tablo için indeksler `kulliyat`
--
ALTER TABLE `kulliyat`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `rehber`
--
ALTER TABLE `rehber`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rlink` (`rlink`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `bolgeler`
--
ALTER TABLE `bolgeler`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `iksirler`
--
ALTER TABLE `iksirler`
  MODIFY `iid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Tablo için AUTO_INCREMENT değeri `karakterler`
--
ALTER TABLE `karakterler`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tablo için AUTO_INCREMENT değeri `kulliyat`
--
ALTER TABLE `kulliyat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Tablo için AUTO_INCREMENT değeri `rehber`
--
ALTER TABLE `rehber`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
