       <?php
        $sekme="head";
        $sayfa="Külliyat"; 
        include "inc/header.php";
        include "inc/baglanti.php";
       ?>
      <section class="ne text-white pt-5">
           <div class="container">
               <div class="row mt-1">
                    <div class="col-md-7">
                    <h1 class="text-danger text-center ">Yaratık Kulliyatı</h1>
                    <div class="container yazi ">
                      <p class="text-center pbosluk">
                       Yaratık Külliyatımızda, karşılaştığınız canavarlarla ilgili ipuçları bulabirsiniz.
                      </p>
                      <p>
                         Yaratık külliyatı ya da yaratık ansiklopedisi genellikle, canlı ya da efsanevi farklı yaratıklar hakkında bilgi içeren bir kitaptır. The Witcher 3: Wild Hunt ve genişleme paketleri Hearts of Stone ve Blood and Wine'da, Geralt olarak sürdürdüğümüz maceramızda keşfedilecek ve öldürülecek birçok yaratıkla karşılaşacağız. Yeni yaratıklarla karşılaştıkça, onlar hakkında bildiğiniz tüm bilgiler bu kitaba kaydedilir. Bu bilgiler, sadece aradığımız canavarı bularak ve onlarla etkileşime girerek veya belirli kitapları okuyarak bulunabilir. Geralt'ın bir hayvanı veya canavarı öldürdüğünde, bölgedeki diğer canavarları kendine çeken gerçek bir kokusu olduğunu unutmayın. 
                      </p>
                    </div>
                    </div>
                    <div class="col-md-5 mt-5">
                        <h5 class="colordred ">İçindekiler</h5>
                        <ul>
                            <li>
                                <a href="#b">Böceksiler</a> 
                            </li>
                            <li>
                                <a href="#dir">Direngenler</a>
                            </li>
                            <li>
                                <a href="#dra">Drakanoidler</a>
                            </li>
                            <li>
                                <a href="#e">Elementalar</a>
                            </li>
                            <li>
                                <a href="#h">Hayaletler</a>
                            </li>
                            <li>
                                <a href="#ha">Hayvanlar</a>
                            </li>
                            <li>
                                <a href="#lanet">Lanetliler</a>
                            </li>
                            <li>
                                <a href="#mlz">Melezler</a>
                            </li>
                            <li>
                                <a href="#nekro">Nekrofagiller</a>
                            </li>
                            <li>
                                <a href="#ogr">Ogridler</a>
                            </li>
                            <li>
                                <a href="#vm">Vampirler</a>
                            </li>
                        </ul>
                    </div>
               </div>
            </div>
           </div>
        </div>
        <section class="page-section bg-light" id="portfolio">
                            <div class="text-justify">
                                <h2 class="border-bottom colordred" id="b">Böceksiler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=1");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>"/>
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="dir">Direngenler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=2");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="dra">Drakanoidler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=3");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="e">Elementalar</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=4");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="h">Hayaletler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=5");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="ha">Hayvanlar</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=6");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="lanet">Lanetliler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=7");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="mlz">Melezler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=8");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="nekro">Nekrofagiller</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=9");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="ogr">Ogridler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=10");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
        <section class="page-section bg-light ptap" id="portfolio">
                            <div class="text-left">
                                <h2 class="border-bottom colordred" id="vm">Vampirler</h2>
                                <h3 class="section-subheading text-muted"></h3>
                            </div>
                        <div class="container">
                        <div class="row">
                            <?php 
                                 $sorgu=$db->prepare("select * from kulliyat where katagori=11");
                                 $sorgu->execute();

                                 while ($goster=$sorgu->fetch()) {
                            ?> 
                                <div class="col-md-2">
                                <div class="portfolio-item">
                                    <a class="portfolio-link" data-toggle="modal" href="#yaratik<?=$goster['id']?>">
                                        <img class="img-fluid d-block rounded-lg foto-border" src="img/kulliyat/<?=$goster['foto']?>" alt="" />
                                    </a>
                                    <div class="portfolio-caption">
                                        <div class="portfolio-caption-heading "><?=$goster['baslik']?></div>
                                    </div>  
                                </div>
                                </div>
                            <?php
                                  } 
                            ?>
                    </div>
                </div>
        </section>
       </section>
       <?php
            $sorgu2=$db->prepare("select * from kulliyat");
            $sorgu2->execute();

            while ($goster2=$sorgu2->fetch()) {
                ?> 
            <div class="portfolio-modal modal fade" id="yaratik<?=$goster2['id']?>">
            <div class="modal-dialog ne">
                <div class="modal-yeter">
                <section class="pt-5 text-white">
             <div class="row mt-1">
                <div class="col-md-7 pl-5 mx-5">
                    <h2 class="text-center colordred "><p><?=$goster2['baslik']?></p></h2>
                    <div class="yazi text-justify mx-4">
                        <p><?=$goster2['p1']?></p>
                    </div>
                    <h3 class="border-bottom text-left colordred">Dövüş Taktikleri</h3>
                    <div class="yazi text-justify">
                        <?=$goster2['dt']?>
                    </div>
                </div>
              <div class="col-md-3 mx-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="2" class="text-center w colordred"><h4 class=" pt-2"><?=$goster2['baslik']?></h4></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><<img src="img/kulliyat/<?=$goster2['foto']?>" class="img-fluid"></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Genel Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Zayıflık</th>
                                <td id="td" class="fsize text-left"><?=$goster2['zayıflık']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Sınıf</th>
                                <td id="td" class="fsize text-left"><?=$goster2['sınıf']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Bölge</th>
                                <td id="td" class="fsize text-left"><?=$goster2['gy']?></td>
                            </tr>
                        </tbody>
                    </table>
              </div>
        </section>
                </div>
            </div>
        </div>
        <?php
            }
        ?>
       
        
    <script>
        const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].pause()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].play()
                        }
                    )
                }
    </script>
        <!-- Footer-->
        <?php
        include "inc/footer.php";
        ?>