    <!--Navigation-->
    <?php
        $sekme="head";
        $sayfa="Ana Sayfa"; 
        include "inc/baglanti.php";
        include "inc/header.php";
    ?>
    <!--Slider-->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/slider/w1.jpg" class="d-block w-100" width="100%">
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="colorred w">Witcher 3: Wild Hunt</h5>
                    <p>The Witcher 3: Wild Hunt, CD Projekt RED tarafından geliştirilen, Warner Bros. Interactive
                        Entertainment tarafından Kuzey Amerika'da, Namco Bandai Games tarafından ise Avrupa'da
                        yayımcılığı yapılan üçüncü şahıs nişancı türü aksiyon rol yapma oyunudur.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/slider/w2.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="colorred w">Witcher 3: Wild Hunt</h5>
                    <p>Serinin diğer oyunları gibi Rivyalı Geralt'ın hikâyesini konu alır. İkinci oyunun sonunda yaşanan
                        olayların üzerinden altı ay geçer ve Geralt'ın hafızası yerine gelir. Hafızasını geri kazanan
                        Geralt, kayıp aşkı Yennefer'ı aramaya başlar. Ardından Ciri'yi geri getirmek için Emhyr var
                        Emreis'den hayatının en büyük kontratını alır ancak bu hiç kolay olmayacaktır. Çünkü Ciri'nin
                        peşinde Wild Hunt vardır.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/slider/w3.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="colorred w">Witcher 3: Wild Hunt</h5>
                    <p>Ana karakter Witcher Rivyalı Geralt, çocukluğundan beri savaş, iz sürme, simya ve sihir konusunda
                        eğitilmiş ve mutajenler tarafından toksinlere karşı daha güçlü, daha hızlı ve dirençli hale
                        getirilmiş bir canavar avcısıdır.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"></span>
        </button>
    </div>
    
    <!--İnformation-->
    <section class="ne pt-5 text-white d-flex">
        <div class="container">
            <div class="row mt-6">
                <div class="col-md-4">
                <img src="img/wcd.png" width="120%" class=" img-fluid d-flex wcd">
                    <div class="col">
                        <table class="table table-bordered table-dark table-responsive-lg">
                            <thead>
                                <div class="text-center pb-3 bilgiler">BİLGİLER</div>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row" class="text-left">Geliştirici</th>
                                    <td class="text-danger text-right">CD Projekt RED</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="text-left">Çıkış tarihi</th>
                                    <td class="text-danger text-right">19 Mayıs 2015</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="text-left">Tür</th>
                                    <td class="text-danger text-right">RPG</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="text-left">Platform</th>
                                    <td class="text-danger text-right">
                                        Microsoft Windows
                                        PlayStation 4
                                        Xbox One
                                        Nintendo Switch
                                        PlayStation 5 (bekleniyor)
                                        Xbox Series X (bekleniyor)
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="text-left">Motor</th>
                                    <td class="text-danger text-right">REDengine Umbra 3, PhysX ve SpeedTree ile
                                        birlikte
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-md-7">
                    <h2 class="colordred mb-5 text-justify w">The Witcher 3: Wild Hunt</h2>
                    <p class="yazi"> The Witcher 3: Wild Hunt, CD Projekt RED tarafından geliştirilen ve Rivyalı
                        Geralt'ın hikayesini
                        anlatan oyun serisinin üçüncü ve son bölümüdür. Başlangıçta 2014 yılının sonunda piyasaya
                        sürülmek üzere planlanan oyun önce 24 Şubat 2015'e ertelenmiş, ardından 19 Mayıs 2015'te
                        çıkışını gerçekleştirmiştir. Piyasaya sürüldükten sonraki iki hafta içerisinde dünya çapında
                        4 milyondan fazla kopya satarak The Witcher 2: Assassins of Kings'ın satış rakamlarını ikiye
                        katlamıştır.</p>
                    <p class="yazi">
                        Önceki oyunlardan farklı olarak Witcher 3, 100 saatten fazla oynanış süresine sahip çok bölgeli
                        bir açık dünyaya oyunudur. Yayımlanan eski makalelerde yapımcıların, açık dünya deneyimi
                        konusunda Skyrim'e benzer ancak Skyrim'den %20 daha büyük bir açık dünyaya sahip olmak
                        istedikleri belirtilmiştir. Geliştiriciler, Bethesda'nın açık dünya konseptinde takdir
                        edilecek çok şey olduğunu, ancak oyundaki kusurları tekrar etmemek için çaba sarf ettiklerini
                        belirttiler. Daha önceki oyunlarda olduğu gibi, Geralt'ın kararlarının sonuçları hikayenin
                        ilerleyişini etkilemektedir. Oyun yeni REDengine 3 kullanılarak inşa edilmiş ve önceki Witcher
                        oyunlarının hayranlarından gelen geri bildirimler göz önünde bulundurularak tasarlanmıştır.
                    </p>
                    <div class="d-flex">
                        <iframe class="wbw" width="600" height="340" src="https://www.youtube.com/embed/L6VxXGPifbE"
                            title="YouTube video player" allow="accelerometer; clipboard-write; gyroscope;"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--WWorld-->
    <section class="pt-5 text-white ne" id="bolgeler">
        <h2 class="w text-center colordred">
            The Witcher world
        </h2>
        <div class="container ">
            <div class="text-center yazi">The Witcher dünyasındaki birçok krallığı ve şehri keşfedin. Vahşi Avı yok etme
                arayışına devam ederken Beyaz Kurt'un karşılaştığı Coğrafya hakkında bilgi edinin. Açık dünya ortamında
                gezinmeye yardımcı olmak için topluluk tarafından geliştirilen haritaları kullanın.</div>
            <div>
                 <div class="row mt-6 bolgeler section">
                <?php
                    $sorgu=$db->prepare("select * from bolgeler");
                    $sorgu->execute();
                    while ($goster=$sorgu->fetch()) {
                    ?> 
                    <div class="col-md-4 centera">
                        <p class="text-white text-center sehir">
                            <a href="bolgeler/<?=$goster['blink'];?>"><img src="img/sehirler/<?=$goster['bolge_foto']?>" class="img-fluid d-block mx-auto rounded-lg sehirg">
                                <p class="yazsehir w text-white text-center"><?=$goster['bolge_adi'];?></p>
                            </a>
                        </p>
                    </div>
                    <?php 
                         }
                    ?>
                </div>
            </div>
    </section>
    <!--Guides-->
    <section class=" pt-5 text-white ne" id="rehber">
        <h2 class="w text-center colordred">
            The Witcher Rehber
        </h2>
        <div class="container">
            <div class="text-center yazi">
                Savaş, simya, canavar avı ve witcher işaretleri ile ilgili kılavuzlarımızı okuyarak The Witcher
                3: Wild Hunt'ta hayatta kalmak için gereken becerileri ve stratejileri keşfedin. Witcher becerileri,
                savaş taktikleri, ölümcül canavarların güçlü ve zayıf yönleri ve mükemmel karışımların nasıl
                oluşturulacağı hakkında her şeyi öğrenin.</div>
                <div>
                <div class="row mt-6 bolgeler">
                    <?php 
                         $sorgu2=$db->prepare("select * from rehber");
                         $sorgu2->execute();
                         while ($goster2=$sorgu2->fetch()) {
                    ?>
                    <div class="col-md-4 centera">
                        <p class="text-white text-center sehir">
                            <a href="guides/<?=$goster2['rlink'];?>"><video loop src="img/guides/<?=$goster2['rvideo']?>" poster="img/guides/<?=$goster2['rfoto']?>" 
                              class="img-fluid d-block mx-auto radius rounded-lg clip guidef">
                                    <p class="yazsehir text-white text-center"><?=$goster2['rbaslik']?></p>
                            </a>
                        </p>
                    </div>
                    <?php 
                       }
                    ?>
                </div>
            </div>
            <script>
                const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].play()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].pause()
                        }
                    )
                }
            </script>
    </section>
    <!--eklenti-->
    <div class="ne">
        <h2 class="colordred text-left w border-bottom">Eklentiler</h2>
        <div class="row mt-7">
            <div class="col-md-5">
                <img src="img/eklenti.jpg" width="90%" class="wcd img-fluid">
            </div>
            <div class="col-md-7">
                <p class="yazie text-justify bow"> 7 Nisan 2015'te CD Projekt RED, The Witcher 3: Wild Hunt için Hearts of
                    Stone ve Blood
                    and Wine başlıklı iki büyük genişleme paketi duyurdu. CD Projekt RED, her iki genişleme paketinin de
                    yeni düşmanlar, karakterler ve teçhizat içerdiğini söyledi. Hearts of Stone 13 Ekim 2015'te ve Blood
                    and
                    Wine 31 Mayıs 2016'da piyasaya sürülmüştür.
                </p>
            </div>
            <div class="col-md-12">
                <h3 class="colordred w text-left bow">Hearts Of Stone</h3>
                <p class="yazi text-justify bow">Hearts of Stone paketi, Geralt'ı, Velen'den Oxenfurt'un gizemli
                    sokaklarına kadar sürükleyeceği 10 saatin üzerinde yeni bir maceraya götürecek ve burada gizemli bir
                    Ayna Tüccarı'ndan aldığı kontratı tamamlamaya çalışacak. Büyük bir aldatmacayla karşılaşan
                    Geralt'ın, olayı çözmek ve yaptığı sözleşmeyi tamamlaması için kılıcına ve zekasına ihtiyacı olacak.
                </p>
            </div>
            <div class="col-md-12">
                <h3 class="colordred w text-left hos">Blood And Wine</h3>
                <p class="yazi text-justify hos">Blood and Wine paketi sizi oyunun yepyeni bir bölgesi olan ve savaşın
                    henüz uğramadığı Toussaint'a götürüyor. Geralt, krallığı tehdit eden, güzelliğin korkuyla mücadele
                    ettiği, sevgi ve aldatmanın kol kola olduğu 20 saatin üzerinde bir maceraya atılıyor.</p>
            </div>
        </div>
    </div>
    <!-- Footer-->
    <?php
        include "inc/footer.php";
    ?>