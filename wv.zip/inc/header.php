<?php
    $link = "../"
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">   
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title> <?=$sayfa?> | WitcherVerse</title>
    <link rel="icon" type="image/x-icon" href="img/wlogoa.png" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic" rel="stylesheet"
        type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="css/wfont/stylesheet.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/mystyles.css">
</head>

<link rel="stylesheet" href="css/mystyles.css">
<nav class="navbar navbar-expand-lg navbar-dark w-renk " id="mainNav">
        <div class="container">
            <a class="navbar-logo" href="<?php if($sekme=="icice") echo $link;?>anasayfa"><img src="<?php if($sekme=="icice") echo $link;?>img/navbar-lgo.png" width="100%"></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
                aria-label="Toggle navigation">
                Menü
                <i class="fas fa-bars ml-1"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase nav2">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger mx-3" href="<?php if($sekme=="icice") echo $link;?>anasayfa#rehber">Rehber</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger mx-3" href="<?php if($sekme=="icice") echo $link;?>anasayfa#bolgeler">Bölgeler</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger mx-3" href="<?php if($sekme=="icice") echo $link;?>kulliyat">Yaratık
                            Külliyatı</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger mx-3" href="<?php if($sekme=="icice") echo $link;?>karakterler">Karakterler</a></li>
                </ul>
            </div>
        </div>
</nav>
<body  class="">