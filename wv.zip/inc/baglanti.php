<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=wverse;charset=utf8","root","");
} 
catch (PDOException $hata){
echo "hata var ".$hata->getMessage();
}
?>