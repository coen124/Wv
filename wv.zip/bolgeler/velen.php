    <link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Velen";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
        <section class="pt-5 text-white ne">
             <div class="row mt-1">
              <div class="col-md-7 ml-5 mr-5">
              <h1 class="w text-danger text-center "> velen</h1>
                  <div class="container yazi ">
                      <p class="text-center pbosluk">
                      No Man's Land olarak da adlandırılan Velen, Temerya'nın kuzeyinde, başkenti Gors Velen şehrin kuzey'inde yer alan bir ildir.
                      </p>
                      <p>
                      The Witcher 3: Wild Hunt'ta eski eyalet, Novigrad ve Oxenfurt şehirlerine yakın sınırlarla Nilfgaard işgali altında savaşın parçaladığı bir bataklık haline geldi. Oyunun ana bölgelerinden biridir ve yoğun ormanlarla dolu bataklıkları, arsanın karanlık ve gizemli unsurlarını temsil eder.
                      </p>
                      <p>
                      
                      </p>
                  </div>
                  <div class="container yazi">
                     <h2 class="border-bottom text-white">Tarih</h2>
                      <div class="row">
                        <div class="col-md-7"><p class="text-left">
                        Velen, Nilfgaard güçlerinin Kuzey Krallığı ordularıyla çarpıştığı bir yerdir. Savaş hem kuzeyi hem de güneyi zorlayarak, iki tarafında geri çekilmesi yüzünden şehir ıssız bir yere dönüşür.
                        </p>
                    </div>
                    <div class="col-md-5">
                        <img src="img/velen.png" width="100%" class="img-fluid d-block mx-auto rounded-sm" alt="">        
                    </div>
                        <div class="container"><p>   Hatta takma adını da burdan alır. Halkı öldürüldü, tecavüze uğradı ve asıldı. Bütün bu acılar, Velen halkının yaşamak zorunda olduğu sefaleti daha da artırdı.</p> 
                        <p>
                             Ne Kuzey Redanya Krallığı'nın ne de Nilfgaard'ın orduları buradaki muharebelerinde zafer kazanamadı. Her iki tarafın da geçici olarak geri çekilmesinin ardından, Velen'de kararlı (acımasız ve ahlak dışı olsa da) eylem ve güç yoluyla, daha çok Kanlı Baron takma adıyla tanınan eski bir Temeryalı komutan olan Phillip Strenger liderliğinde yarı özerk bir devlet kuruldu. Eski Temerya ordusunun kalıntılarından oluşan minik bir orduya sahip.
                        </p>
                    </div>
                    </div>
                  </div>
              </div>
              <div class="col-md-3 mt-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="5" class="text-center w colordred"><h2 class="w">Velen</h2></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><img src="img/velen_arma.png" class="img-fluid arma" alt="velen arma" width="40%"></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Genel Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">İktidar</th>
                                <td id="td" class="fsize text-left"> Tamerya (eskiden). Nilfgaard tarafından feth edildi</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Yönetenler</th>
                                <td id="td" class="fsize text-left">Kanlı Baron</td>
                            </tr>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Toplumsal Bilgi</th>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Başkent</th>
                                <td id="td" class="fsize text-left">Gors Velen</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Dil</th>
                                <td id="td" class="fsize text-left">Ortak dil</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Para birimi</th>
                                <td id="td" class="fsize text-left">Oren</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Harita</th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/velenmap.png"><img src="img/velenmap.png" class="img-fluid map" alt="velen arma"></a></th>
                            </tr>
                        </tfoot>
                    </table>
              </div>
              <div class="col-md-11 mt-3 text-justify mx-5">
              <p class="yazi" id="yazid" >
                    Baron'un kuralları sert ve belki de ülkenin kendisini yansıtıyor. Adamları disiplinsiz ve yerel halka gaddarca davranmaktan fazlasıyla hoşlanıyor. Gıda ve erzak gibi kanun ve düzen de yetersiz. Bu nedenle, Velen, benzer mizaçtaki bir adam tarafından yönetilen, savaşın harap ettiği ve affetmeyen bir yer olan No Man's Land olarak bilinir hale geldi. Kanlı Baron, Redanya ve Nilfgaard arasındaki son savaşların ardından Baron ve güçleri tarafından işgal edilen yıkık bir kale olan Karga Tüneği'nden yönetir.
                </p>
              </div>
            </div>
        </section>
        
        
    <?php
        include "../inc/footer.php";
    ?>