<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="EVİM";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
        <section class="pt-5 text-white ne">
             <div class="row mt-1">
              <div class="col-md-7 ml-5 mr-5">
              <h2 class="w text-danger text-center "> Kaer Morhen</h2>
                  <div class="container yazi ">
                      <p class="text-center pbosluk mb-1">
                        "Korkacak bir şey yok" dedi Witcher ve elini kızın omzuna koydu. "Burası Kaer Morhen, Witcherların yuvasıdır. Burada bir zamanlar güzel bir şato vardı. Uzunca bir zaman önce."
                      </p>
                      <p class="text-right colordred font-italic">
                          The Witcher Elflerin Kanı (Sayfa 54)
                      </p>
                      <p>
                      Kaer Morhen (Kadim dilde Caer a'Muirehen, Eski Deniz Kalesi anlamına gelmektedir.) Kurt Okulu Witcherlarının eğitildiği eski bir şatodur. Caer a'Muirehen ismi, zamanında bu toprakların su altında olduğunu göstermektedir. Ayrıca şatonun altındaki taş tabakada deniz canlılarının fosillerine rastlanmaktadır. Şimdiyse Kaedwen Krallığı'nın dağlarında, Gwenllech Nehri'nin yakınlarında yer almaktadır.
                      </p>
                      <p>
                      Eski zamanlarda, Witcherlar burada eğitilmiş, mutasyonlara maruz kalmışlardı. Uzun zaman önce, birtakım bağnazlar, sihirbazların da yardımıyla Kaer Morhen'e saldırmış, birçok Witcher'ı ve öğrenciyi katletmişti. Bazı Witcherlar kışın dinlenmek için tekrar Kaer Morhen'e dönse de, Vesemir bu şatoda yaşayan son Witcher olarak bilinir. Bu hikaye the witcher: Nightmare of the wolf filmi ile bağlantılıdır.
                      </p>
                      <p>
                      Şatoya sadece İz denilen, Kaer Morhen şatosunu çepeçevre saran, engellerle donatılmış, Witcherların hızlı koşma ve nefes kontrolü çalışmaları yaptıkları gizli bir patikadan ulaşılabilmektedir. Genç Witcherlar buraya kendi aralarında Eziyet de demektedirler.
                      </p>
                  </div>
                  <div>
                      <img src="img/kaermorhen;(.jpg" class="rounded-lg" width="100%" alt="">
                  </div>
              </div>
              <div class="col-md-3 mt-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="5"><h2 class="w colordred font-italic text-center">Kaer Morhen</h2></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/kaermurihen.png"><img src="img/kaermurihen.png" class="img-fluid map" alt="novigrad şehri"></a></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Diğer adıyla</th>
                                <td id="td" class="fsize text-left">Caer a'Muirehen <br> Eski Deniz Kalesi</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Tür</th>
                                <td id="td" class="fsize text-left">Kale</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Yönetici</th>
                                <td id="td" class="fsize text-left">Witcher Kurt Okulu</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Ülke</th>
                                <td id="td" class="fsize text-left">Kaedwen</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Bölge</th>
                                <td id="td" class="fsize text-left">Hertch</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Harita</th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/vesemir;(.jpg"><img src="img/vesemir;(.jpg" class="img-fluid map" alt="velen arma"></a></th>
                            </tr>
                        </tfoot>
                    </table>
              </div>

        </section>
        
        
    <?php
        include "../inc/footer.php";
    ?>