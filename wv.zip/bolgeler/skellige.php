<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Skellige";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
        <section class="pt-5 text-white ne">
             <div class="row mt-1">
              <div class="col-md-7 ml-5 mr-5">
              <h1 class="w text-danger text-center ">Skellige</h1>
                  <div class="container yazi ">
                      <p class="text-center pbosluk">
                      Genellikle Skellige Adaları veya Skellige Adaları olarak anılan Skellige, bir takımadadır ve Kuzey Krallıklarından biridir. Altı adadan oluşan grup, Büyük Deniz'de, Cintra kıyılarında ve Cidaris ve Verden'in güneybatısında yer almaktadır. Efsanevidir, birçok denizi aşan rakipsiz korsanları ve hızlı uzun gemileri ile ünlüdür.
                      </p>
                      <p>
                        Halkı, geleneksel tartışmalar sırasında yedi büyük klanın halkı tarafından seçilen Skellige Adaları Kralı'nın altında birleşiyor. Ancak uygulamada, krallar aynı klandan veya en azından akrabadır.
                      </p>
                      <p>
                         Kuzey'in çoğuyla ilişkileri her zaman gergin olsa da, en azından söylemek gerekirse, Kraliçe Calanthe ve Skellige'li Eist Tuirseach arasındaki evlilik nedeniyle uzun zamandır Cintra'nın müttefikleriydiler. Kral Eist'in Marnadal Savaşı'nda ölümünden sonra, Adalılar intikam almak için baskınlarını Nilfgaard İmparatorluğu'na yoğunlaştırdı.
                      </p>
                  </div>
                  <div class="container yazi">
                     <h2 class="border-bottom text-white">Tarih</h2>
                     <div>
                        <h4 class="text-white">İnsan öncesi çağlar</h4>
                    </div>
                      <div class="row">
                        <div class="col-md-7"><p class="text-left">
                            Bir insanın ilk ortaya çıkışından önce, adalar görünüşe göre onu devler ve buz devleriyle paylaşan Aen Seidhe elfleri yaşıyordu.
                        </p>
                    </div>
                    <div class="col-md-5">
                        <img src="img/skellige-giant.png" width="100%" class="img-fluid d-block mx-auto rounded-sm" alt="">        
                    </div>
                        <div class="container">
                            <h4 class="text-white">İnsan yerleşimin kuruluşu</h4>
                        </div>
                        <div class="container">
                        <p>  
                        Adalara yerleşmeye gelen insanlar önce kendilerini, kendi adalarının egemen yöneticileri olarak, klan reisleri olan bağımsız klanlara böldüler.
                        </p> 
                        <p>
                        Böylece, Skellige'nin küçük bölgeleri, yıllar boyunca Kıta'nın yükselen güçleri tarafından birkaç kez işgal edildi. Bu tür istilacıların en tehditkar olanı, kralları tam bir ayaklanma girişiminde bulunan Cidaris'ti, ancak hiç kimse onları fethetmeyi başaramadı. Aksine, daha uzaktaki daha küçük adacıklardan gelen daha büyük krallıkların ve medeni olmayan barbarların tehdidi, Skellige'lilerin birleşmesine neden oldu. Skellige daha sonra, kontlar arasından seçilen bir kral tarafından yönetilen, seçmeli bir monarşi oldu.
                        </p>
                    </div>
                    </div>
                  </div>
              </div>
              <div class="col-md-3 mt-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="5" class="text-center w colordred"><h2 class="w">Skellige</h2></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><img src="img/skellige-arma.png" class="img-fluid arma" alt="skellige arma" width="40%"></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Genel Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Yönetim şekli</th>
                                <td id="td" class="fsize text-left"> <a href="https://tr.wikipedia.org/wiki/Seçimli_monarşi" target="_blank">Seçimli monarşi</a></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Tip</th>
                                <td id="td" class="fsize text-left">Krallık</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Yönetici</th>
                                <td id="td" class="fsize text-left">Kral/Kraliçe</td>
                            </tr>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Toplumsal Bilgi</th>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Başkent</th>
                                <td id="td" class="fsize text-left">Kaer Trolde</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Dil</th>
                                <td id="td" class="fsize text-left">Skellige jargonu</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Harita</th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/skellige-map.png"><img src="img/skellige-map.png" class="img-fluid map" alt="velen arma"></a></th>
                            </tr>
                        </tfoot>
                    </table>
              </div>
              </div>
              <div class="col-md-11 mt-3 text-left mx-5">
              <p class="yazi" id="yazid" >
                    
                </p>
              </div>
            </div>
        </section>
        
        
    <?php
        include "../inc/footer.php";
    ?>