<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Novigrad";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
        <section class="pt-5 text-white ne">
             <div class="row mt-1">
              <div class="col-md-7 ml-5 mr-5">
              <h1 class="w text-danger text-center "> Novigrad</h1>
                  <div class="container yazi ">
                      <p class="text-center pbosluk">
                            Novigrad, Redania içinde özgür bir şehirdir ve bu nedenle bu krallığın yönetimine tabi değildir. Kıtadaki en büyük limanlardan biridir ve yaklaşık 30.000 nüfusu ile Kuzey'in en büyük şehirlerinden biridir.
                      </p>
                      <p>
                      Herhangi bir gerçek metropol gibi, Novigrad'da da birçok fabrika var ve mümkün olan her şeyi sunan her türden ustaya ev sahipliği yapıyor ve hatta ara sıra dolandırıcı veya gaspçı bile bulabilirsiniz. Şehir ayrıca çok sayıda bankaya ev sahipliği yapıyor ve hatta bir hayvanat bahçesine sahip. Ebedi Ateşin şehrin sakinlerini canavarlar dahil tüm kötülüklerden koruduğu söylenir. Oxenfurt Akademisi mimarları tarafından incelikle tasarlandıkları için kalın şehir duvarları hiçbir zaman aşılmadı.
                      </p>
                      <p>
                      
                      </p>
                  </div>
                  <div class="container yazi">
                     <h2 class="border-bottom text-white">Tarih</h2>
                      <div class="row">
                        <div class="col-md-7"><p class="text-left">
                        İnsanların İlk yerleşiminden önce Novigrad küçük bir elf yerleşimiydi. İlk insan gemileri Pontar Deltası'na vardığında, şehir elfler tarafından terk edildi ve kısa sürede ilk kralın atası olan Kral Sambuk tarafından yaratılan yeni bir ülkenin Redanya'nın başkenti oldu.
                        </p>
                    </div>
                    <div class="col-md-5 mt-5">
                        <img src="img/novigrad2.jpg" width="100%" class="img-fluid d-block mx-auto rounded-sm" alt="">        
                    </div>
                        <div class="container">
                            <h4 class="text-white">Bağımsızlığa Giden Yol</h4>
                        </div>
                        <div class="container">
                        <p>  
                             Gururlu Vestibor'un saltanatı sırasında Novigrad, Yedi Yıl Savaşı sırasında Tamerya tarafından fethedildi. Redanya'nın başkenti daha sonra Tretogor'a taşındı ve Novigrad uzun bir süre Temerya şehri oldu.
                        </p> 
                        <p>
                            Durum, Vestibor'un torunu Cesur III. Radovid'in saltanatı sırasında değişti. Uzun müzakerelerden sonra bir uzlaşmaya varıldı ve metropol özgür bir şehir olarak kabul edildi.
                        </p>
                    </div>
                    </div>
                  </div>
              </div>
              <div class="col-md-3 mt-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="5" class="text-center w colordred"><h2 class="w">Novigrad</h2></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/novigrad.jpg"><img src="img/novigrad.jpg" class="img-fluid map" alt="novigrad şehri"></a></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Genel Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Tipi</th>
                                <td id="td" class="fsize text-left"> Metropol</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Yönetici</th>
                                <td id="td" class="fsize text-left">Novigrad hiyeraşisi (sözde)<br> Yeraltı suç örgütleri (fiili)</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Ülke</th>
                                <td id="td" class="fsize text-left">Redanya</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Bölge</th>
                                <td id="td" class="fsize text-left">Pontar deltası</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Konum</th>
                                <td id="td" class="fsize text-left">Pontar'ın kuzey kıyısı, Tretogor'un batısında ve Oxenfurt'un kuzeybatısında</td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Nüfus</th>
                                <td id="td" class="fsize text-left">30,000</td>
                            </tr>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Arma</th>
                            </tr>
                            <tr>
                            <th scope="col" colspan="2"><img src="img/novi-arma.png" class="img-fluid arma" alt="velen arma" width="40%"></th>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Harita</th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href="img/novi-map.png"><img src="img/novi-map.png" class="img-fluid map" alt="velen arma"></a></th>
                            </tr>
                        </tfoot>
                    </table>
              </div>
        </section>
        
        
    <?php
        include "../inc/footer.php";
    ?>