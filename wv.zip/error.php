<?php
        $sekme="head";
        $sayfa="Hata"; 
        include "inc/header.php";
?>
<br><br><br><br><br><br><br><br>
<div class="text-center pt-5">
<h1 class="mt-5 mt-5 text-danger">
    SAYFA BULUNAMADI !!!!!
</h1>
<img src="assets/img/404icon.png" alt="">
<h4 class="pt-5 text-danger" >
    Sayfa taşınmış veya silinmiş olabilir,
</h4>
<h5 class="pt-5 text-danger" >
     veya yolunu şaşırmış olabilirsin. Witcher.
</h5>
<h6 class="pt-5 text-danger" >
     Brokilon ormanlarında sakın kaybolayım deme!!!
     <br><br><br><br><br><br><br><br><br><br><br><br>
</h6>
</div>
<?php
        include "inc/footer.php";
?>