        <?php
        $sekme="head";
        $sayfa="Karakterler"; 
        include "inc/header.php";
        include "inc/baglanti.php";
         ?>
        <section class="page-section bg-light ne" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="w colordred">Karakterler</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
                <div class="row">
                    <?php 
                        $sorgu=$db->prepare("select * from karakterler");
                        $sorgu->execute();

                        while ($goster=$sorgu->fetch()) {
                           ?> 
                        <div class="col-md-3 ">
                            <div class="portfolio-item">
                                <a class="portfolio-link" data-toggle="modal" href="#karakter<?=$goster['id']?>">
                                    <img class="img-fluid d-block rounded-lg foto-border" src="img/karakterler/<?=$goster['kfoto']?>" alt="" />
                                </a>
                                 <div class="portfolio-caption">
                                     <div class="portfolio-caption-heading "><?=$goster['kad']?></div>
                                </div>  
                            </div>
                        </div>
                    <?php
                        } 
                    ?>
                </div>
            </div>
        </section>
        <?php
            $sorgu2=$db->prepare("select * from karakterler");
            $sorgu2->execute();

            while ($goster2=$sorgu2->fetch()) {
                ?> 
            <div class="portfolio-modal modal fade " id="karakter<?=$goster2['id']?>">
            <div class="modal-dialog ne">
                <div class="modal-content">
                <section class="pt-5 text-white">
             <div class="row mt-1">
                <div class="col-md-8">
                    <h2 class="text-center colordred w"><p><?=$goster2['kad']?></p></h2>
                    <div class="yazi text-justify mx-4">
                        <p><?=$goster2['p1']?></p>
                        <p><?=$goster2['p2']?></p>
                        <p><?=$goster2['p3']?></p>
                    </div>
                    <h3 class="<?php if($goster2['id']<>4) echo "border-bottom text-left colordred";?>"><?php if($goster2['id']<>4) echo "Geçmişi";?></h3>
                    <div class="yazi text-justify">
                        <?=$goster2['biyo']?>
                    </div>
                </div>
              <div class="col-md-3 mt-5 mr-auto">
                    <table class=" table-striped table-dark table-bordered fsize mt-5">
                        <thead>
                            <tr>
                                <th scope="col" colspan="2" class="text-center w colordred"><h4 class="w pt-2"><?=$goster2['kad']?></h4></th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2"><a target="_blank" href=""><img src="img/karakterler/<?=$goster2['kfoto2']?>" class="img-fluid"  alt="Triss Merigold"></a></th>
                            </tr>
                            
                            <tr class="text-white bg-info">
                                <th colspan="2" class="text-center" scope="col">Genel Bilgi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Lakap(lar)</th>
                                <td id="td" class="fsize text-left"><?=$goster2['lakap']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Meslek</th>
                                <td id="td" class="fsize text-left"><?=$goster2['meslek']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Güç(ler)</th>
                                <td id="td" class="fsize text-left"><?=$goster2['güc']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Irk</th>
                                <td id="td" class="fsize text-left"><?=$goster2['irk']?></td>
                            </tr>
                            <tr id="tr">
                                <th id="th" scope="row" class="text-danger">Şehir</th>
                                <td id="td" class="fsize text-left"><?=$goster2['sehir']?></td>
                            </tr>
                        </tbody>
                    </table>
              </div>
        </section>
                </div>
            </div>
        </div>
        <?php
            }
        ?>

        <!-- Footer-->
        <?php
        include "inc/footer.php";
        ?>