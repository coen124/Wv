-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 12 May 2022, 23:43:23
-- Sunucu sürümü: 10.4.22-MariaDB
-- PHP Sürümü: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `wverse`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolgeler`
--

CREATE TABLE `bolgeler` (
  `id` int(10) NOT NULL,
  `bolge_adi` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `bolge_aciklama` varchar(10000) COLLATE utf8_turkish_ci NOT NULL,
  `bolge_foto` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `bolge_pp` varchar(100) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `bolgeler`
--

INSERT INTO `bolgeler` (`id`, `bolge_adi`, `bolge_aciklama`, `bolge_foto`, `bolge_pp`) VALUES
(1, 'Velen', '  No Man\'s Land olarak da adlandırılan Velen , Temerya\'nın kuzeyinde, başkenti Gors Velen\'in kuzeyinde yer alan bir eyalettir .\r\n\r\n  The Witcher 3: Wild Hunt\'ta eski eyalet, Novigrad ve Oxenfurt şehirlerine yakın sınırlarla Nilfgaard işgali altında savaşın parçaladığı bir bataklık haline geldi . Oyunun ana bölgelerinden biridir ve yoğun ormanlarla dolu bataklıkları, arsanın karanlık ve gizemli unsurlarını temsil eder.\r\n\r\n', 'velen.jpg', 'velen.png'),
(2, 'Novigrad', 'Novigrad , Redania içinde özgür bir şehirdir ve bu nedenle bu krallığın yönetimine tabi değildir. Kıtadaki en büyük limanlardan biridir ve yaklaşık 30.000 nüfusu ile Kuzey\'in en büyük şehirlerinden biridir .\r\n\r\nHerhangi bir gerçek metropol gibi, Novigrad\'da da birçok fabrika var ve mümkün olan her şeyi sunan her türden ustaya ev sahipliği yapıyor ve hatta ara sıra dolandırıcı veya yankesici bile bulabilirsiniz. Şehir ayrıca çok sayıda bankaya ev sahipliği yapıyor ve hatta bir hayvanat bahçesine sahip. Ebedi Ateşin şehrin sakinlerini canavarlar dahil tüm kötülüklerden koruduğu söylenir. Oxenfurt Akademisi mimarları tarafından incelikle tasarlandıkları için kalın şehir duvarları hiçbir zaman ihlal edilmemiştir.\r\n\r\nNovigrad, hem kalıcı sakinlerden hem de şehirde uzun ve kısa süreli ziyaretlerde bulunan alışılmadık derecede renkli bir grup tarafından iskan edilmektedir. Sıradan kasaba halkı, ahır bekçileri ve zanaatkarların kalabalığı arasında en dikkat çekici olanlar, daha cüretkar meslekleri icra edenlerdir. Şehirde ordu yok ama bir gizli servisi , her zaman var olan bir Tapınak Muhafızı ve güçlü bir Tapınak Filosu var .', 'novigrad.jpg', 'novigrad.jpg'),
(3, 'Skellige', 'Genellikle Skellige Adaları veya Skellige Adaları olarak anılan Skellige , bir takımadadır ve Kuzey Krallıklarından biridir . Altı adadan oluşan grup, Büyük Deniz\'de , Cintra kıyılarında ve Cidaris ile Verden\'in güneybatısında yer alır . Efsanevidir, birçok denizi aşan rakipsiz korsanları ve hızlı uzun gemileri ile ünlüdür.\r\n\r\nHalkı , geleneksel tartışmalar sırasında yedi büyük klanın halkı tarafından seçilen Skellige Adaları Kralı altında birleşiyor. Ancak uygulamada, krallar aynı klandan veya en azından akrabadır.\r\n\r\nKuzey\'in çoğuyla ilişkileri her zaman gergin olsa da, en azından söylemek gerekirse, Kraliçe Calanthe ve Skellige\'den Eist Tuirseach arasındaki evlilik nedeniyle uzun zamandır Cintra\'nın müttefikleriydiler. Kral Eist\'in Marnadal Savaşı\'nda ölümünden sonra , Adalılar intikam almak için baskınlarını Nilfgaard İmparatorluğu\'na yoğunlaştırdı .', 'skellige.jpg', 'skellige.jpg'),
(4, 'Oxenfurt', 'Oxenfurt , Pontar nehrinin kuzey kıyısında ve Novigrad\'ın güneydoğusunda bulunan bir Redan şehridir . Kuzey Krallıklarının en büyüğü olan Akademisi ile ünlüdür . \r\n\r\nTretogor\'un yaklaşık üç yüz mil batısında .\r\nÖğrenciler, sanatçılar, akademisyenler ve özgür düşünenler için hareketli ve müstehcen bir sığınaktır. Burada, modada ve düşüncede yeni yollar açarken, dünyanın geri kalanının da yakında takip edeceğinden emin olarak, gençler (aslında her zaman olmasa da, ruhen) üstün gelirler.', 'oxenfurt.jpg', 'oxenfurt.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(10) NOT NULL COMMENT '\r\n',
  `kad` varchar(20) COLLATE utf8_turkish_ci NOT NULL COMMENT 'Kullanıcı adı',
  `ksifre` varchar(20) COLLATE utf8_turkish_ci NOT NULL COMMENT 'Kullanıcı Şifre',
  `ban` int(1) NOT NULL,
  `tarih` varchar(20) COLLATE utf8_turkish_ci NOT NULL DEFAULT current_timestamp(),
  `yetki` varchar(10) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kad`, `ksifre`, `ban`, `tarih`, `yetki`) VALUES
(1, 'admin', 'wverse85189', 0, '2022-05-10 21:38:45', 'ekle_sil');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `bolgeler`
--
ALTER TABLE `bolgeler`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bolge_adi` (`bolge_adi`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kad` (`kad`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `bolgeler`
--
ALTER TABLE `bolgeler`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '\r\n', AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
