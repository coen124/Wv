<?php
$sayfa = "Güncelle";
include "inc/aheader.php";
if ($_SESSION["yetki"]!="1") {
    echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
    echo "<script>Swal.fire({
        title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
        icon:'warning',
        confirmButtonText: 'Kapat',
        }).then((result) => {
        if (result.isConfirmed) {
        window.location.href='index.php'
        } 
        })</script>";
        exit;
}

if ($_GET) {
    $id = $_GET['id'];
    $sorgu = $db->prepare("select * from kullanicilar where id=?");
    $sorgu->execute([$id]);
    $goster = $sorgu->fetch();

    if ($_POST) {
        $kad = $_POST['k'];
        $parola = $_POST['s'];
        $tparola = $_POST['st'];
        $yetki = $_POST['yetki'];
        $aktif = $_POST['aktif'];
        if ($parola != $tparola) {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
                 title: 'Şifreler Uyuşmuyor',
                 icon:'warning',
                confirmButtonText: 'Kapat',
                }).then((result) => {
                    if (result.isConfirmed) {
                    window.location.href='kullanicilar.php'
                    } 
                })
                                 
               </script>";
            exit();
        } else {
            $sorgu2 = $db->prepare("UPDATE kullanicilar set kad=?, parola=?, yetki=?, aktif=? where id=?");
            $guncelle = $sorgu2->execute([$kad, $parola, $yetki, $aktif,$id]);
            
            if ($guncelle) {
                echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
                echo "<script>Swal.fire({
                    title: 'Başarılı',
                    icon:'success',
                    confirmButtonText: 'Kapat',
                    }).then((result) => {
                    if (result.isConfirmed) {
                    window.location.href='kullanicilar.php'
                    } 
                    })</script>";
            }
        }
    }
?>
    <main>
        <form method="POST">
            <div class="container-fluid px-4">
                <h1 class="mt-4">Kullanıcılar</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Kullanıcılar</li>
                    <li class="breadcrumb-item active">Düzenle</li>
                </ol>
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        <div class="card-body mx-2 row">
                            <div class="form-group col-md-3 pt-3">
                                <label>Kullanıcı Adı</label>
                                <input type="text" name="k" value="<?= $goster['kad'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-3 pt-3">
                                <label>Şifre</label>
                                <input type="password" name="s" value="<?= $goster['parola'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-3 pt-3">
                                <label>Şifre Tekrar</label>
                                <input type="password" name="st" value="<?= $goster['parola'] ?>" required class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="card-body mx-2 row">
                            <div class="form-group col-md-3 pt-3">
                                <label>Yetki</label>
                                <input type="text" name="yetki" value="<?= $goster['yetki'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-3 pt-3">
                                <label>Aktif</label>
                                <input type="text" name="aktif" value="<?= $goster['aktif'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-3 pt-51">
                                <input type="submit" value="Güncelle" class="btn btn-primary" required class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>
<?php
}
?>

<?php
include "inc/afooter.php";
?>
