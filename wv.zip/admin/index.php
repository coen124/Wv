<?php
$sayfa = "Panel";
include "inc/aheader.php";
?>
<main>
    <h2 class="text-center pt-3 colordred">ARAMIZA HOŞGELDİN WİTCHER</h2>
    
    <img src="../img/genel/dreamteam.jpg" class="img-fluid">
</main>
<?php
include "inc/afooter.php";
?>