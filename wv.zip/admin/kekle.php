<?php
$sayfa = "Ekle";
include "inc/aheader.php";
if ($_SESSION["yetki"] != "1") {
    echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
    echo "<script>Swal.fire({
        title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
        icon:'warning',
        confirmButtonText: 'Kapat',
        }).then((result) => {
        if (result.isConfirmed) {
        window.location.href='index.php'
        } 
        })</script>";
    exit;
}

?>
<main>
    <form method="POST">
        <div class="container-fluid px-4">
            <h1 class="mt-4">Kullanıcılar</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Witcher Verse</li>
                <li class="breadcrumb-item active">Kullanıcılar</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-3 pt-3">
                            <label>Kullanıcı Adı</label>
                            <input type="text" name="k" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-3">
                            <label>Şifre</label>
                            <input type="password" name="s" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-3">
                            <label>Şifre Tekrar</label>
                            <input type="password" name="st" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-header">
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-3 pt-3">
                            <label>Yetki</label>
                            <input type="text" name="yetki" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-3">
                            <label>Aktif</label>
                            <input type="text" name="aktif" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-51">
                            <input type="submit" value="Kayıt Ol" class="btn btn-primary" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>
<?php
if ($_POST) {
    $kad = $_POST['k'];
    $sifre = $_POST['s'];
    $tsifre = $_POST['st'];
    $aktif = $_POST['aktif'];
    $yetki = $_POST['yetki'];
    if ($sifre != $tsifre) {
        echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>Swal.fire({
         title: 'Şifreler Uyuşmuyor',
         icon:'warning',
        confirmButtonText: 'Kapat',
        })
                         
       </script>";
        exit();
    } else {
        $sorgu = $db->prepare("insert into kullanicilar(kad,parola,yetki,aktif) values(?,?,?,?)");
        $ekle = $sorgu->execute([$kad, $sifre, $aktif, $yetki]);
        if ($ekle) {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
             title: 'Kullanıcı Eklendi',
             icon:'success',
            confirmButtonText: 'Kapat',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href='kullanicilar.php'
                } 
            })         
           </script>";
        }
    }
}

?>
<?php
include "inc/afooter.php";
?>