<?php
                $sayfa = "Rehberler";
                include "inc/aheader.php";
                
                $sorgu = $db->prepare("select * from bolgeler");
                $sorgu->execute();
                ?>
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Bölgeler</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Witcher Verse</li>
                            <li class="breadcrumb-item active">Bölgeler</li>
                        </ol>


                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>

                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="myTable" width="100%" cellspasing="0">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Bolge Adı</th>
                                                <th>Görsel</th>
                                                <th>id</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while ($sonuc = $sorgu->fetch()) {
                                            ?>
                                                <tr>
                                                    <td class="text-center">
                                                        <?php
                                                            if ($_SESSION['yetki']!=3) {
                                                               ?> 
                                                        <a href="bguncelle.php?id=<?=$sonuc['id'] ?>"><span class="fa fa-edit fa-2x"></span></a>
                                                        <?php 
                                                        }
                                                        ?>
                                                        
                                                        
                                                    </td>
                                                    <td><?= $sonuc['bolge_adi']; ?></td>
                                                    <td class="text-center"><img src="../img/sehirler/<?= $sonuc['bolge_foto']; ?>" class="img-fluid" width="150px"></td>
                                                    <td><?= $sonuc['id']; ?></td>
                                                </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php
                include "inc/afooter.php";
                ?>