<?php
    session_start();
     if (!(isset($_SESSION["oturum"]) and isset($_SESSION)=="6789")) {
        header("location:login.php");
    }
    include "../inc/baglanti.php";
?>
<!DOCTYPE html>
<html lang="tr">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link rel="icon" type="image/x-icon" href="../img/wlogoa.png" />
        <title><?=$sayfa?></title>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.12.1/af-2.4.0/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/datatables.min.css"/>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/mystyles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">Yönetim Paneli</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <div class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                
            </div>
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        
                        <li><a class="dropdown-item" href="logout.php" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Çıkış Yap</a></li>
                    </ul>
                </li>
            </ul>
            
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                             <div class="sb-sidenav-menu-heading">Yönetim</div>
                            <a class="nav-link" href="kullanicilar.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fas fa-user"></i></div>
                                Kullanıcılar
                            </a>
                            <div class="sb-sidenav-menu-heading">Düzenlenebilir</div>
                            <a class="nav-link" href="rehberler.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fa-brands fa-buffer"></i></div>
                                Rehberler
                            </a>
                            <a class="nav-link" href="bolgeler.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fas fa-globe"></i></div>
                                Bölgeler
                            </a>
                            <a class="nav-link" href="iksirler.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fa-solid fa-flask"></i></div>
                                İksirler
                            </a>
                            <a class="nav-link" href="kuliyat.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fa-solid fa-skull"></i></div>
                                Yaratık Külliyatı
                            </a>
                            
                            <a class="nav-link" href="karakterler.php">
                                <div class="sb-nav-link-icon <?php if($sayfa=="bölgeler" or $sayfa=="rehberler") echo "active";?>"><i class="fa-solid fa-address-card"></i></div>
                                Karakterler
                            </a>
                        </div>
                        
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Giriş yapıldı:</div>
                        <?=$_SESSION['kad']?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">