<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=wverse","root","");
} 
catch (PDOException $hata){
echo "hata var ".$hata->getMessage();
}
?>