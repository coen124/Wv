<?php
$sayfa = "Kulliyat";
include "inc/aheader.php";

$sorgu = $db->prepare("select * from kulliyat");
$sorgu->execute();
?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Yaratık Külliyatı</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">WitcherVerse</li>
            <li class="breadcrumb-item active">Yaratıklar</li>
        </ol>


        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                <?php if ($_SESSION["yetki"] != "3") {
                ?>
                    <a href="yaratik.php"><i class="fa-solid fa-plus"></i></a>
                <?php
                }
                ?>


            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="myTable" width="100%" cellspasing="0">
                        <thead>
                            <tr>
                                <td>Canavar Görselleri </td>
                                <th>Yaratık İsim</th>
                                <th>Kategori</th>
                                <th>Zayıflıkları</th>
                                <th>Kategori</th>
                                
                                <?php
                                if ($_SESSION["yetki"] != "3") {
                                ?>
                                    <th>Düzelt</th>
                                    <th>Sil</th>
                                <?php
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($sonuc = $sorgu->fetch()) {
                            ?>
                                <tr>
                                    <td class="text-center"><img src="../img/kulliyat/<?=$sonuc['foto']; ?>" class="img-fluid" width="150px"></td>
                                    <td><?= $sonuc['baslik']; ?></td>
                                    <td><?= $sonuc['katagori']; ?></td>
                                    <td><?= $sonuc['zayıflık']; ?></td>
                                    <td><?= $sonuc['sınıf']; ?></td>
                                    
                                    <?php
                                    if ($_SESSION["yetki"] != "3") {
                                    ?>
                                       <td class="text-center"><a href="yaratikguncelle.php?id=<?= $sonuc['id'] ?>"><span class="fa fa-edit fa-2x"></span></a></td>
                                    <?php
                                    }
                                    ?>
                                        <?php
                                        if ($_SESSION["yetki"] != "3") {

                                        ?>
                                            <td class="text-center"><a href="yaratiksil.php?id=<?= $sonuc['id'] ?>&sil=<?= $sonuc['foto'] ?>"><span class="fa fa-trash fa-2x text-danger"></span></a></td>
                                        <?php
                                        }
                                        ?>

                                   
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    include "inc/afooter.php";
?>
