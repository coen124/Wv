
    <?php 
    include "inc/aheader.php";
    if ($_SESSION["yetki"]=="3") {
        echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>Swal.fire({
            title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
            icon:'warning',
            confirmButtonText: 'Kapat',
            }).then((result) => {
            if (result.isConfirmed) {
            window.location.href='index.php'
            } 
            })</script>";
            exit;
    }
			include "../inc/baglanti.php";
			if ($_GET) {
				$id=$_GET['id'];
				$sorgu2=$db->prepare("delete from iksirler where iid=?");
				$sil=$sorgu2->execute([$id]);

                $silfoto=$_GET['sil'];
                unlink("../guides/img/$silfoto");
                
			}
                echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
                echo "<script>Swal.fire({
                    title: 'Silme İşlemi Başarılı',
                    icon:'info',
                    confirmButtonText: 'Kapat',
                    }).then((result) => {
                    if (result.isConfirmed) {
                    window.location.href='iksirler.php'
                    } 
                    })</script>";
include "inc/afooter.php";
?>


