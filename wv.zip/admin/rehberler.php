                <?php
                $sayfa = "Rehberler";
                include "inc/aheader.php";

                $sorgu = $db->prepare("select * from rehber");
                $sorgu->execute();
                ?>
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Rehberler</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item active">Rehberler</li>
                        </ol>


                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>

                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="myTable" width="100%" cellspasing="0">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Başlık</th>
                                                <th>Fotoğraf</th>
                                                <th>Video</th>
                                                <th>Anahtar</th>
                                                <th>id</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while ($sonuc = $sorgu->fetch()) {
                                            ?>
                                                <tr>
                                                    <td class="text-center">
                                                        <?php
                                                        if ($_SESSION["yetki"]!="3") {
                                                          ?>  
                                                            <a href="rehberguncelle.php?id=<?= $sonuc['id'] ?>"><span class="fa fa-edit fa-2x"></span></a>
                                                        <?php
                                                        }
                                                        ?>
                                                        
                                                    </td>
                                                    <td><?= $sonuc['rbaslik']; ?></td>
                                                    <td class="text-center"><img src="../img/guides/<?= $sonuc['rfoto']; ?>" class="img-fluid" width="150px"></td>
                                                    <td>
                                                        <div class="vida"><video loop src="../img/guides/<?= $sonuc['rvideo'] ?>" width="150px" class="img-fluid d-block mx-auto radius rounded-lg clip"></div>
                                                    </td>
                                                    <td><?= $sonuc['anahtar']; ?></td>
                                                    <td><?= $sonuc['id']; ?></td>
                                                </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <script>
                    const clip = document.querySelectorAll('.clip');
                    for (let i = 0; i < clip.length; i++) {
                        clip[i].addEventListener('mouseout',
                            function(e) {
                                clip[i].play()
                            }
                        )
                    }
                </script>
                <?php
                include "inc/afooter.php";
                ?>