<?php
$sayfa = "Güncelle";
include "inc/aheader.php";

if ($_GET) {
    if ($_SESSION["yetki"]=="3") {
        echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>Swal.fire({
            title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
            icon:'warning',
            confirmButtonText: 'Kapat',
            }).then((result) => {
            if (result.isConfirmed) {
            window.location.href='index.php'
            } 
            })</script>";
            exit;
    }
    $iid = $_GET['id'];
    $sorgu = $db->prepare("select * from iksirler where iid=?");
    $sorgu->execute([$iid]);
    $goster = $sorgu->fetch();

    if ($_POST) {
        $ad = $_POST['iad'];
        $aciklama = $_POST['iaciklama'];
        $foto=$_POST['foto'];
        $kat = $_POST['ikat'];

            $sorgu2 = $db->prepare("UPDATE iksirler set iksirad=?, iksirbuff=?, iksirfoto=?, iksirkategori=? where iid=?");
            $guncelle = $sorgu2->execute([$ad, $aciklama,$foto, $kat,$iid]);
            
            if ($guncelle) {
                echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
                echo "<script>Swal.fire({
                    title: 'Başarılı',
                    icon:'success',
                    confirmButtonText: 'Kapat',
                    }).then((result) => {
                    if (result.isConfirmed) {
                    window.location.href='iksirler.php'
                    } 
                    })</script>";
            }
    }
?>
    <main>
    <form method="POST">
        <div class="container-fluid px-4">
            <h1 class="mt-4">İksirler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">WitcherVerse</li>
                <li class="breadcrumb-item active">İksir Güncelle</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir adı</label>
                            <input type="text" name="iad" value="<?=$goster['iksirad']?>" required class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir Foto.png</label>
                            <input type="text" value="<?=$goster['iksirfoto']?>" name="foto" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir kategori</label>
                            <select id="kat1" name="ikat" class="form-control">
                                <option value="1">Genel</option>
                                <option value="2">İyileştirici</option>
                                <option value="3">Defansif</option>
                                <option value="4">Agresif</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-header">
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-12 pt-3">
                            <label>İksir açıklaması</label>
                            <input type="text" name="iaciklama" value="<?=$goster['iksirbuff']?>" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-51">
                            <input type="submit" value="Güncelle" class="btn btn-primary" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>
<?php
}
?>

<?php
include "inc/afooter.php";
?>
