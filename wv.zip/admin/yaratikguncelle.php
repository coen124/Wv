<?php
$sayfa = "Güncelle";
include "inc/aheader.php";
if ($_GET) {
    if ($_SESSION["yetki"] == "3") {
        echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>Swal.fire({
                title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
                icon:'warning',
                confirmButtonText: 'Kapat',
                }).then((result) => {
                if (result.isConfirmed) {
                window.location.href='kuliyat.php'
                } 
                })</script>";
        exit;
    }

    $id = $_GET['id'];
    $sorgu = $db->prepare("select * from kulliyat where id=?");
    $sorgu->execute([$id]);
    $goster = $sorgu->fetch();

    if ($_POST) {
        $yukleklasor = "../img/kulliyat/";
        $tmp_name = $_FILES['foto']['tmp_name'];
        $name = $_FILES['foto']['name'];
        $boyut = $_FILES['foto']['size'];
        $tip = $_FILES['foto']['type'];
        $uzanti = substr($name, -4, 4);
        $rastgelesayi1 = rand(10000, 50000);
        $rastgelesayi2 = rand(10000, 50000);
        $resimad = $rastgelesayi1 . $rastgelesayi2 . $uzanti;

        if (strlen($name) == 0) {
            echo "<script>Swal.fire({
            title: 'Dosya Seçiniz',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        }

        if ($boyut > (1024 * 1024 * 3)) {
            echo "<script>Swal.fire({
            title: 'Dosya Boyutu Çok Büyük',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        }
        if ($tip != 'image/png' && $uzanti != '.png' && $tip != 'image/jpg' && $uzanti != '.jpeg') {
            echo "<script>Swal.fire({
            title: 'Lütfen png veya jpg uzantılı görsel yükleyiniz.',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        }
        move_uploaded_file($tmp_name, "$yukleklasor/$resimad");

        $iad = $_POST['iad'];
        $kat1 = $_POST['kat1'];
        $ip = $_POST['ip'];
        $dt = $_POST['dt'];
        $zyf = $_POST['zyf'];
        $kat2 = $_POST['kat2'];
        $bolge = $_POST['bolge'];

        $sorgu2 = $db->prepare("UPDATE kulliyat set id=?, baslik=?, foto=?, katagori=?, zayıflık=?, sınıf=? , gy=? , p1=? , dt=? where `kulliyat`.`id` = $id");
        $guncelle = $sorgu2->execute([$id,$iad,$resimad,$kat1,$zyf,$kat2,$bolge,$ip,$dt]);

        if ($guncelle) {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
                        title: 'Başarılı',
                        icon:'success',
                        confirmButtonText: 'Kapat',
                        }).then((result) => {
                        if (result.isConfirmed) {
                        window.location.href='kuliyat.php'
                        } 
                        })</script>";
        }
    }
?>
    <main>
        <form method="POST" enctype="multipart/form-data">
            <div class="container-fluid px-4">
                <h1 class="mt-4">Yaratık Külliyatı</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">WitcherVerse</li>
                    <li class="breadcrumb-item active">Yaratık Güncelle</li>
                </ol>
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        <div class="card-body mx-2 row">
                            <div class="form-group col-md-4 pt-3">
                                <label>Yaratık Adı</label>
                                <input type="text" name="iad" value="<?= $goster['baslik'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-4 pt-3">
                                <label>Yaratık foto</label>
                                <input type="file" name="foto" class="form-control">
                            </div>
                            <div class="form-group col-md-4 pt-3">
                                <label>Yaratık kategori</label>
                                <select id="kat1" name="kat1" value="<?= $goster['katagori'] ?>" class="form-control">
                                    <option value="1">Böceksi</option>
                                    <option value="2">Direngen</option>
                                    <option value="3">Drakonid</option>
                                    <option value="4">Elementa</option>
                                    <option value="5">Hayalet</option>
                                    <option value="6">Hayvan</option>
                                    <option value="7">Lanetli</option>
                                    <option value="8">Melez</option>
                                    <option value="9">Nekrofagi</option>
                                    <option value="10">Ogroid</option>
                                    <option value="11">Vampir</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="card-body mx-2 row">
                            <div class="form-group col-md-12 pt-3">
                                <label>İlk Paragraf</label>
                                <input type="text" style="height: 70px;" name="ip" value="<?= $goster['p1'] ?>" required class="form-control"></input>
                            </div>
                            <div class="form-group col-md-12 pt-3">
                                <label>Dövüş Taktikleri</label>
                                <input type="text" style="height: 70px;" name="dt" value="<?= $goster['dt'] ?>" required class="form-control"></input>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-header">
                        <div class="card-body mx-2 row">
                            <div class="form-group col-md-7 pt-3">
                                <label>Zayıflık</label>
                                <input type="text" name="zyf" value="<?= $goster['zayıflık'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-7 pt-3">
                                <label>Sınıf</label>
                                <select id="katy" requierd name="kat2" value="<?= $goster['sınıf'] ?>" class="form-control">
                                    <option value="Böceksi">Böceksi</option>
                                    <option value="Direngen">Direngen</option>
                                    <option value="Drakonoid">Drakonoid</option>
                                    <option value="Elementa">Elementa</option>
                                    <option value="Hayalet">Hayalet</option>
                                    <option value="Hayvan">Hayvan</option>
                                    <option value="Lanetli">Lanetli</option>
                                    <option value="Melez">Melez</option>
                                    <option value="Nekrofagi">Nekrofagi</option>
                                    <option value="Ogroid">Ogroid</option>
                                    <option value="Vampir">Vampir</option>
                                </select>
                            </div>
                            <div class="form-group col-md-7 pt-3">
                                <label>Bölge</label>
                                <input type="text" name="bolge" value="<?= $goster['gy'] ?>" required class="form-control">
                            </div>
                            <div class="form-group col-md-7 pt-51">
                                <input type="submit" value="Güncelle" class="btn btn-primary" required class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>
<?php
}
?>
<?php
include "inc/baglanti.php";
?>