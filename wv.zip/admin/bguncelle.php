<?php
    $sayfa="Güncelle";
    include "inc/aheader.php";
    if ($_SESSION["yetki"]=="3") {
        echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>Swal.fire({
            title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
            icon:'warning',
            confirmButtonText: 'Kapat',
            }).then((result) => {
            if (result.isConfirmed) {
            window.location.href='index.php'
            } 
            })</script>";
            exit;
    }
    if ($_GET) {
        $id=$_GET['id'];
        $sorgu=$db->prepare("select * from bolgeler where id=?");
        $sorgu->execute([$id]);
        $goster=$sorgu->fetch();
    ?>
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Bölgeler</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Witcher Verse</li>
                            <li class="breadcrumb-item active">Bölgeler/Güncelle</li>
                        </ol>
                        
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                
                            </div>
                            <div class="card-body mx-2">
                               <form action="bguncelle.php" method="POST" enctype="multipart/form-data">
                                    <div class="form-group pt-3">
                                       <label>id</label>
                                       <input type="text" name="id" required class="form-control" value="<?=$goster['id']?>">
                                    </div>
                                    <div class="form-group pt-3">
                                       <label>Başlığı</label>
                                       <input type="text" name="bolgead" required class="form-control" value="<?=$goster['bolge_adi']?>">
                                    </div>
                                    <div class="form-group pt-3">  
                                       <div class="row ">
                                            <div class="col-md-6">
                                                
                                                <div class="form-group pt-1">  
                                                    <label>Link</label>
                                                    <input type="text" name="blink" required class="form-control" value="<?=$goster['blink']?>">
                                              </div>
                                              <div class="form-group pt-1">  
                                                    <label>Foto:</label>
                                                    <input type="text" name="bolge_foto" required class="form-control" value="<?=$goster['bolge_foto']?>">
                                              </div>
                                              <div class="form-group pt-3"> 
                                                <label>Anahtar</label>
                                                <input type="text" name="anahtar" required class="form-control" value="<?=$goster['anahtar']?>">
                                             </div>
                                             
                                                <div class="form-group pt-4">
                                                  <input type="submit" name="" value="Güncelle" class="btn btn-primary">
                                                </div>
                                            </div>
                                            <div class="col-md-3 mx-5">
                                                <div>
                                                    <h4 class="mb-2 text-center colordred">Şu anki fotoğraf</h4>   
                                                    <img src="../img/sehirler/<?=$goster['bolge_foto'];?>"class="img-fluid" width="">
                                                </div>
                                            </div>  
                                       </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </main>
                <?php
                    }
                ?>
                <?php
                    if ($_POST) {

                        $id = $_POST['id'];
                        $bolge_adi=$_POST['bolgead'];
                        $bolge_foto=$_POST['bolge_foto'];
                        $blink=$_POST['blink'];
                        $anahtar=$_POST['anahtar'];
                        
                        $guncellesorgu=$db->prepare("UPDATE bolgeler SET id=?, bolge_adi =?, bolge_foto=?, blink=?, anahtar=? WHERE id=?");
                        $guncelle=$guncellesorgu->execute([$id,$bolge_adi,$bolge_foto,$blink,$anahtar,$id]);
                        if ($guncelle) {
                             echo'<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
                            echo "<script>Swal.fire({
                             title: 'Başarılı',
                             icon:'success',
                             confirmButtonText: 'Kapat',
                           }).then((result) => {
                             if (result.isConfirmed) {
                                 window.location.href='bolgeler.php'
                             } 
                           })</script>";
                        }   
                    }
                ?>
                <?php
                    include "inc/afooter.php";
                ?>