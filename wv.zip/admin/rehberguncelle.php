<?php
    $sayfa="Güncelle";
    include "inc/aheader.php";

    if ($_GET) {
        if ($_SESSION["yetki"]=="3") {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
                title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
                icon:'warning',
                confirmButtonText: 'Kapat',
                }).then((result) => {
                if (result.isConfirmed) {
                window.location.href='index.php'
                } 
                })</script>";
                exit;
        }
        $id=$_GET['id'];
        $sorgu=$db->prepare("select * from rehber where id=?");
        $sorgu->execute([$id]);
        $goster=$sorgu->fetch();
    ?>
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Rehberler</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item active">Rehberler/Güncelle</li>
                        </ol>
                        
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                
                            </div>
                            <div class="card-body mx-2">
                               <form action="rehberguncelle.php" method="POST">
                                    <div class="form-group pt-3">
                                       <label>id</label>
                                       <input type="text" name="id" required class="form-control" value="<?=$goster['id']?>">
                                    </div>
                                    <div class="form-group pt-3">
                                       <label>Başlığı</label>
                                       <input type="text" name="rbaslik" required class="form-control" value="<?=$goster['rbaslik']?>">
                                    </div>
                                    <div class="form-group pt-3">  
                                       <div class="row ">
                                            <div class="col-md-6">
                                                
                                                <div class="form-group pt-1">  
                                                    <label>Link</label>
                                                    <input type="text" name="rlink" required class="form-control" value="<?=$goster['rlink']?>">
                                                </div>
                                              <div class="form-group pt-3"> 
                                                <label>Anahtar</label>
                                                <input type="text" name="anahtar" required class="form-control" value="<?=$goster['anahtar']?>">
                                             </div>
                                                <div class="form-group pt-1">  
                                                    <label>Foto İsim:</label>
                                                    <input type="text" name="foto" required class="form-control" value="<?=$goster['rfoto']?>">
                                                </div>
                                                <div class="form-group pt-1">  
                                                    <label>Video İsim:</label>
                                                    <input type="text" name="vido" required class="form-control" value="<?=$goster['rvideo']?>">
                                                </div>
                                                <div class="form-group pt-4">
                                                  <input type="submit" value="Güncelle" class="btn btn-primary">
                                                </div>
                                            </div>
                                            <div class="col-md-3 mx-5">
                                                <div>
                                                    <h4 class="mb-2 text-center colordred">Şu anki fotoğraf</h4>   
                                                    <img src="../img/guides/<?=$goster['rfoto'];?>"class="img-fluid" width="">
                                                </div>
                                                <div class="pt-4">
                                                    <h4 class="mb-2 text-center colordred">Şu anki video</h2>
                                                    <video loop src="../img/guides/<?=$goster['rvideo']?>" class="img-fluid d-block mx-auto radius rounded-lg clip">
                                                </div>
                                            </div>  
                                       </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </main>
                <?php
                    }
                ?>
                <?php
                if ($_POST) {
                    $id=$_POST['id'];
                    $rbaslik=$_POST['rbaslik'];
                    $rlink=$_POST['rlink'];
                    $anahtar=$_POST['anahtar'];
                    $rfoto=$_POST['foto'];
                    $rvideo=$_POST['vido'];
                       
   
                   $sorgu2=$db->prepare("update rehber set id=?, rbaslik=?, rlink=?, anahtar=?, rfoto=?, rvideo=? where id=?");
   
                   $guncelle=$sorgu2->execute([$id,$rbaslik,$rlink,$anahtar,$rfoto,$rvideo,$id]);
                   if ($guncelle) {
                        echo'<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
                       echo "<script>Swal.fire({
                        title: 'Başarılı',
                        icon:'success',
                        confirmButtonText: 'Kapat',
                      }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href='rehberler.php'
                        } 
                      })</script>";
                       
                   }   
                }
                ?>
                
                <?php
                    include "inc/afooter.php";
                ?>
                <script>
                const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].play()
                        }
                    )
                }
                </script>