<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Giriş</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="icon" type="image/x-icon" href="../img/wlogoa.png" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4 text-danger">Giriş</h3></div>
                                    <div class="card-body">
                                        <?php
                                            session_start();
                                            include ("../inc/baglanti.php");
                                            if (isset($_SESSION["oturum"]) and isset($_SESSION)=="6789") {
                                                header("location:index.php");
                                            }

                                            
                                            
                                            elseif(isset($_COOKIE["cerez"])){
                                                $sorgu=$db->prepare("select kad,yetki from kullanicilar where aktif=1");
                                                $sorgu->execute();
                                                while ($sonuc=$sorgu->fetch()) {
                                                    if ($_COOKIE["cerez"]==$sonuc['kad']) {

                                                        $_SESSION["oturum"]="6789";
                                                        $_SESSION["kad"]=$sonuc['kad'];
                                                        $_SESSION["yetki"]=$sonuc["yetki"];

                                                        header("location:index.php");
                                                    }
                                                }
                                                
                                            }
                                            
                                            if ($_POST) {
                                                $kad=$_POST['kad'];
                                                $parola=$_POST['parola'];
                                            }

                                        ?>
                                        <form method="post" action="login.php">
                                            <div class="form-floating mb-3 mt-3">
                                                <input class="form-control" id="inputEmail" type="text" name="kad" placeholder="Kullanıcı adı" />
                                                <label for="inputEmail">Kullanıcı Adı</label>
                                            </div>
                                            <div class="form-floating mb-3 mt-3">
                                                <input class="form-control" id="inputPassword" type="password" name="parola" placeholder="Şifre giriniz" />
                                                <label for="inputPassword">Şifre</label>
                                            </div>
                                            <div class="form-check mb-3 mt-3">
                                                <input class="form-check-input" id="inputRememberPassword" type="checkbox" name="cbhatirla" value="" />
                                                <label class="form-check-label " for="inputRememberPassword">Beni Hatırla</label>
                                            </div>
                                            <div class="d-flex align-items-center text-center justify-content-between mt-4 mb-0">
                                                <input type="submit" class="btn btn-primary" value="Giriş"> 
                                            </div>
                                        </form>
                                        <?php
                                            if(empty($kad) or empty($parola)){
                                                echo"<p class='text-center mt-5 text-danger bg-dark mx-4'>Lütfen Kullanıcı adınızı ve parolanızı giriniz.</p>";
                                            }
                                            else{
                                                $sorgu=$db->prepare("select parola,yetki from kullanicilar where kad=:kad and aktif=1");
                                                $sorgu->execute(['kad'=>htmlspecialchars($kad)]);
                                                $sonuc=$sorgu->fetch();
                                                
                                            
                                            if ($parola==@$sonuc['parola']) {
                                               header("location:index.php");

                                               $_SESSION["oturum"]="6789";
                                               $_SESSION["kad"]=$kad;
                                               $_SESSION["yetki"]=$sonuc["yetki"];

                                               if (empty($_POST['cbhatirla'])) {
                                                   setcookie("cerez",$kad,time()+(60*60*24*7));
                                               }
                                            }

                                            else{
                                                echo "<p class='text-center text-warning bg-dark mt-5 mx-4'>Yanlış Kullanıcı adı veya Şifre</p>";
                                            }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
           <?php
                include "inc/afooter.php";
           ?>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
