<?php
$sayfa = "Ekle";
include "inc/aheader.php";
if ($_SESSION["yetki"]=="3") {
    echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
    echo "<script>Swal.fire({
        title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
        icon:'warning',
        confirmButtonText: 'Kapat',
        }).then((result) => {
        if (result.isConfirmed) {
        window.location.href='index.php'
        } 
        })</script>";
        exit;
}

?>
<main>
    <form method="POST" enctype="multipart/form-data">
        <div class="container-fluid px-4">
            <h1 class="mt-4">Karakterler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">WitcherVerse</li>
                <li class="breadcrumb-item active">Karakter ekle</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-4 pt-3">
                            <label>İsim</label>
                            <input type="text" name="isim" required class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Profil Foto</label>
                            <input type="file" name="pfoto" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Foto</label>
                            <input type="file" name="foto" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Lakaplar</label>
                            <input type="text" name="lakap" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Meslek</label>
                            <input type="text" name="meslek" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Güçler</label>
                            <input type="text" name="güc" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Irk</label>
                            <input type="text" name="irk" required class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>Şehir</label>
                            <input type="text" name="sehir" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-header">
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-12 pt-3">
                            <label>İlk Paragraf</label>
                            <textarea type="comment" name="p1" required class="form-control"></textarea>
                        </div>
                        <div class="form-group col-md-12 pt-3">
                            <label>İkinci Paragraf</label>
                            <textarea type="comment" name="p2" required class="form-control"></textarea>
                        </div>
                        <div class="form-group col-md-12 pt-3">
                            <label>Üçüncü Paragraf</label>
                            <textarea type="comment" name="p3" required class="form-control"></textarea>
                        </div>
                        <div class="form-group col-md-12 pt-3">
                            <label>Geçmiş</label>
                            <textarea type="comment" name="gecmis" required class="form-control"></textarea>
                        </div>
                        <div class="form-group col-md-7 pt-51">
                            <input type="submit" value="Ekle" class="btn btn-primary" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>
<?php
if ($_POST) {
    $yukleklasor="../img/karakterler/";
    $tmp_name = $_FILES['foto']['tmp_name'];
    $name = $_FILES['foto']['name'];
    $boyut = $_FILES['foto']['size'];
    $tip = $_FILES['foto']['type'];
    $uzanti=substr($name,-4,4);
    $rastgelesayi1 = rand(10000,50000);
    $rastgelesayi2 = rand(10000,50000);
    $resimad=$rastgelesayi1.$rastgelesayi2.$uzanti;

    if (strlen($name)==0) {
        echo "<script>Swal.fire({
            title: 'Dosya Seçiniz',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }

    if ($boyut > (1024*1024*3)) {
        echo "<script>Swal.fire({
            title: 'Dosya Boyutu Çok Büyük',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
    if ($tip != 'image/png' or $uzanti != '.png' or $tip != 'image/jpg' or $uzanti != '.jpeg') {
        echo "<script>Swal.fire({
            title: 'Lütfen png veya jpg uzantılı görsel yükleyiniz.',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
     move_uploaded_file($tmp_name,"$yukleklasor/$resimad");

    $tmp_name2 = $_FILES['pfoto']['tmp_name'];
    $name2 = $_FILES['pfoto']['name'];
    $boyut2 = $_FILES['pfoto']['size'];
    $tip2 = $_FILES['pfoto']['type'];
    $uzanti2=substr($name2,-4,4);
    $rastgelesayi3 = rand(10000,50000);
    $rastgelesayi4 = rand(10000,50000);
    $resimad2=$rastgelesayi3.$rastgelesayi4.$uzanti2;

    if (strlen($name2)==0) {
        echo "<script>Swal.fire({
            title: 'Dosya Seçiniz',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }

    if ($boyut2 > (1024*1024*3)) {
        echo "<script>Swal.fire({
            title: 'Dosya Boyutu Çok Büyük',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
    if ($tip2 != 'image/png' or $uzanti2 != '.png' or $tip2 != 'image/jpg' or $uzanti2 != '.jpeg') {
        echo "<script>Swal.fire({
            title: 'Lütfen png veya jpg uzantılı görsel yükleyiniz.',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
     move_uploaded_file($tmp_name2,"$yukleklasor/$resimad2");


    $isim = $_POST['isim'];
    $lakap = $_POST['lakap'];
    $meslek = $_POST['meslek'];
    $güc = $_POST['güc'];
    $irk = $_POST['irk'];
    $p1 = $_POST['p1'];
    $p2 = $_POST['p2'];
    $p3 = $_POST['p3'];
    $gecmis = $_POST['gecmis'];
    $sehir = $_POST['sehir'];

        $sorgu = $db->prepare("insert into karakterler(kfoto,kfoto2,kad,p1,p2,p3,lakap,meslek,güc,irk,sehir,biyo) values(?,?,?,?,?,?,?,?,?,?,?,?)");
        $ekle = $sorgu->execute([$resimad2,$resimad,$isim,$p1,$p2,$p3,$lakap,$meslek,$güc,$irk,$sehir,$gecmis]);
        if ($ekle) {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
             title: 'Karakter Eklendi!',
             icon:'success',
            confirmButtonText: 'Kapat',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href='karakterler.php'
                } 
            })         
           </script>";
        }
}

?>
<?php
include "inc/afooter.php";
?>