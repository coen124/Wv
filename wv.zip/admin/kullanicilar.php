
<?php
$sayfa = "Kullanıcılar";
include "inc/aheader.php";

if ($_SESSION["yetki"] == "1" or $_SESSION["yetki"] == "2") {

    $sorgu = $db->prepare("select * from kullanicilar");
    $sorgu->execute();
?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Kullanıcılar</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Witcher Verse</li>
                <li class="breadcrumb-item active">Kullanıcılar</li>
            </ol>


            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <?php
                    if ($_SESSION["yetki"] == "1") {
                    ?>
                        <a href="kekle.php"><i class="fa-solid fa-plus"></i></a>
                    <?php
                    }
                    ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="myTable" cellspasing="0">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>id</th>
                                    <th>İsim</th>
                                    <th>Parola</th>
                                    <th>Yetki</th>
                                    <th>Aktif</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($sonuc = $sorgu->fetch()) {
                                ?>
                                    <tr>
                                        <td class="text-center">

                                            <?php
                                            if ($_SESSION["yetki"] == "1") {
                                            ?>
                                                <a href="kduzenle.php?id=<?= $sonuc['id'] ?>"><span class="fa fa-edit fa-2x"></span></a>
                                            <?php
                                            }
                                            ?>


                                        </td>
                                        <td><?= $sonuc['id']; ?></td>
                                        <td><?= $sonuc['kad']; ?></td>
                                        <td><?php
                                            if ($_SESSION["yetki"] == "2") {
                                                echo "********";
                                            } else {
                                                echo $sonuc['parola'];
                                            }
                                            ?></td>
                                        <td><?= $sonuc['yetki']; ?></td>
                                        <td><span class="fa fa-2x fa-<?=$sonuc['aktif']=="1"?"check text-success":"times text-danger"?>"></span></td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php
    include "inc/afooter.php";
} else {
    echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
    echo "<script>Swal.fire({
        title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
        icon:'warning',
        confirmButtonText: 'Kapat',
        }).then((result) => {
        if (result.isConfirmed) {
        window.location.href='index.php'
        } 
        })</script>";
    exit;
}
?>
