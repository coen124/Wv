<?php
$sayfa = "Karakter";
include "inc/aheader.php";

$sorgu = $db->prepare("select * from karakterler");
$sorgu->execute();
?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Karakterler</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">WitcherVerse</li>
            <li class="breadcrumb-item active">Karakterler</li>
        </ol>


        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                <?php if ($_SESSION["yetki"] != "3") {
                ?>
                    <a href="kaekle.php"><i class="fa-solid fa-plus"></i></a>
                <?php
                }
                ?>


            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="myTable" width="100%" cellspasing="0">
                        <thead>
                            <tr>
                                <th>PFoto</th>
                                <th>Foto</th>
                                <td>İsim</td>
                                <th>Lakap</th>
                                <th>Meslek</th>
                                <th>Güç</th>
                                <th>Irk</th>
                                
                                
                                <?php
                                if ($_SESSION["yetki"] != "3") {
                                ?>
                                    <th>Düzelt</th>
                                    <th>Sil</th>
                                <?php
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($sonuc = $sorgu->fetch()) {
                            ?>
                                <tr>
                                    <td class="text-center"><img src="../img/karakterler/<?=$sonuc['kfoto']; ?>" class="img-fluid" width="150px"></td>
                                    <td class="text-center"><img src="../img/karakterler/<?=$sonuc['kfoto2']; ?>" class="img-fluid" width="150px"></td>
                                    <td><?= $sonuc['kad']; ?></td>
                                    <td><?= $sonuc['lakap']; ?></td>
                                    <td><?= $sonuc['meslek']; ?></td>
                                    <td><?= $sonuc['güc']; ?></td>
                                    <td><?= $sonuc['irk']; ?></td>
                                    
                                    
                                    <?php
                                    if ($_SESSION["yetki"] != "3") {
                                    ?>
                                       <td class="text-center"><a href="kgncl.php?id=<?= $sonuc['id'] ?>"><span class="fa fa-edit fa-2x"></span></a></td>
                                    <?php
                                    }
                                    ?>
                                        <?php
                                        if ($_SESSION["yetki"] != "3") {

                                        ?>
                                            <td class="text-center"><a href="ksil.php?id=<?= $sonuc['id']?>&sil=<?= $sonuc['kfoto'] ?>&sil2=<?= $sonuc['kfoto2'] ?>"><span class="fa fa-trash fa-2x text-danger"></span></a></td>
                                        <?php
                                        }
                                        ?>

                                   
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    include "inc/afooter.php";
?>
