<?php
$sayfa = "Ekle";
include "inc/aheader.php";
if ($_SESSION["yetki"]=="3") {
    echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
    echo "<script>Swal.fire({
        title: 'Bu sayfayı görüntüleyecek yetkiniz yok',
        icon:'warning',
        confirmButtonText: 'Kapat',
        }).then((result) => {
        if (result.isConfirmed) {
        window.location.href='index.php'
        } 
        })</script>";
        exit;
}

?>
<main>
    <form method="POST" enctype="multipart/form-data">
        <div class="container-fluid px-4">
            <h1 class="mt-4">İksirler</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">WitcherVerse</li>
                <li class="breadcrumb-item active">İksir Ekle</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir adı</label>
                            <input type="text" name="iad" required class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir Foto.png</label>
                            <input type="file" name="foto" class="form-control">
                        </div>
                        <div class="form-group col-md-4 pt-3">
                            <label>İksir kategori</label>
                            <select id="kat1" name="ikat" class="form-control">
                                <option value="1">Genel</option>
                                <option value="2">İyileştirici</option>
                                <option value="3">Defansif</option>
                                <option value="4">Agresif</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-header">
                    <div class="card-body mx-2 row">
                        <div class="form-group col-md-12 pt-3">
                            <label>İksir açıklaması</label>
                            <input type="text" name="iaciklama" required class="form-control">
                        </div>
                        <div class="form-group col-md-3 pt-51">
                            <input type="submit" value="İksir Ekle" class="btn btn-primary" required class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>
<?php
if ($_POST) {
    $yukleklasor="../guides/img/";
    $tmp_name = $_FILES['foto']['tmp_name'];
    $name = $_FILES['foto']['name'];
    $boyut = $_FILES['foto']['size'];
    $tip = $_FILES['foto']['type'];
    $uzanti=substr($name,-4,4);
    $rastgelesayi1 = rand(10000,50000);
    $rastgelesayi2 = rand(10000,50000);
    $resimad=$rastgelesayi1.$rastgelesayi2.$uzanti;

    if (strlen($name)==0) {
        echo "<script>Swal.fire({
            title: 'Dosya Seçiniz',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }

    if ($boyut > (1024*1024*3)) {
        echo "<script>Swal.fire({
            title: 'Dosya Boyutu Çok Büyük',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
    if ($tip != 'image/png' or $uzanti != '.png') {
        echo "<script>Swal.fire({
            title: 'Lütfen png uzantılı görsel yükleyiniz.',
            icon:'warning',
           confirmButtonText: 'Kapat',
           })</script>";
        
    }
     move_uploaded_file($tmp_name,"$yukleklasor/$resimad");


    $iad = $_POST['iad'];
    $ikat = $_POST['ikat'];
    $iac = $_POST['iaciklama'];
        $sorgu = $db->prepare("insert into iksirler(iksirad,iksirkategori,iksirbuff,iksirfoto) values(?,?,?,?)");
        $ekle = $sorgu->execute([$iad, $ikat, $iac,$resimad]);
        if ($ekle) {
            echo '<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            echo "<script>Swal.fire({
             title: 'İksir Eklendi Toksitene dikkat et',
             icon:'success',
            confirmButtonText: 'Kapat',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href='iksirler.php'
                } 
            })         
           </script>";
        }
}

?>
<?php
include "inc/afooter.php";
?>