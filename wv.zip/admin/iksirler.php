<?php
$sayfa = "Rehberler";
include "inc/aheader.php";

$sorgu = $db->prepare("select * from iksirler");
$sorgu->execute();
?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">İksirler</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">WitcherVerse</li>
            <li class="breadcrumb-item active">İksirler</li>
        </ol>


        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                <?php if ($_SESSION["yetki"] != "3") {
                ?>
                    <a href="iksirekle.php"><i class="fa-solid fa-plus"></i></a>
                <?php
                }
                ?>


            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="myTable" width="100%" cellspasing="0">
                        <thead>
                            <tr>
                                <td></td>
                                <th>İksir İsim</th>
                                <th>İksir Buff</th>
                                <th>id</th>
                                <th>Kategori</th>
                                <?php
                                if ($_SESSION["yetki"] != "3") {
                                ?>
                                    <th>Düzelt</th>
                                    <th>Sil</th>
                                <?php
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($sonuc = $sorgu->fetch()) {
                            ?>
                                <tr>
                                    <td class="text-center"><img src="../guides/img/<?= $sonuc['iksirfoto']; ?>" class="img-fluid" width="55px"></td>
                                    <td><?= $sonuc['iksirad']; ?></td>
                                    <td><?= $sonuc['iksirbuff']; ?></td>
                                    <td><?= $sonuc['iid']; ?></td>
                                    <td><?= $sonuc['iksirkategori']; ?></td>
                                    <?php
                                    if ($_SESSION["yetki"] != "3") {
                                    ?>
                                       <td class="text-center"><a href="iksirgncl.php?id=<?= $sonuc['iid'] ?>"><span class="fa fa-edit fa-2x"></span></a></td>
                                    <?php
                                    }
                                    ?>
                                        <?php
                                        if ($_SESSION["yetki"] != "3") {

                                        ?>
                                            <td class="text-center"><a href="siliksir.php?id=<?= $sonuc['iid'] ?>&sil=<?= $sonuc['iksirfoto'] ?>"><span class="fa fa-trash fa-2x text-danger"></span></a></td>
                                        <?php
                                        }
                                        ?>

                                   
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    include "inc/afooter.php";
?>
