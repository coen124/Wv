<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Dövüş";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
       <section class="ne text-white pt-5">
           <div class="container">
               <div class="row mt-1">
                    <div class="col-md-7">
                    <h1 class="text-danger text-center ">Dövüş</h1>
                    <div class="container yazi ">
                      <p class="text-center pbosluk">
                      The Witcher 3: Wild Hunt, oyunculara düşmanları yenmek için çeşitli seçenekler ve stratejiler sunan gerçek zamanlı bir savaş sistemine sahiptir.
                      </p>
                      <p>
                      Bir Witcher olarak Geralt of Rivia, yoluna çıkan her şeyi yenmek için kılıçlar, arbaletler, witcher işaretleri ve diğer öğelerle donatılmıştır.
                      </p>
                    </div>
                    </div>
                    <div class="col-md-5 mt-5">
                        <h5 class="colordred ">İçindekiler</h5>
                        <ul>
                            <li>
                                <a href="#td">Temel Dövüş</a> 
                                <ul>
                                    <li><a href="#at">Roach Üstünde Dövüş</a> </li>
                                </ul>
                                <li>
                                    <a href="#silahlar">Silahlar</a>
                                    <ul>
                                        <li><a href="#kılıç">Kılıç</a></li>
                                        <li><a href="#arbalet">Arbalet</a></li>
                                        <li><a href="alchemy.php#bombalar">Bombalar</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="signs.php">İşaretler</a>
                                </li>
                            </li>
                        </ul>
                    </div>
               </div>
           </div>
           <div class="container">
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4" id="td">
                            <h2 class="border-bottom">Temel Dövüş</h2>
                            <div class="yazi mt-3">
                            <p>   
                                İki tür saldırı vardır: hızlı saldırılar ve güçlü saldırılar. Hızlı saldırılar, uzun kombinasyonlar halinde kolayca bir araya getirilebilen hızlı saldırılardır. Çok fazla hasar vermezler, ancak Geralt'ın hücum akışını sürdürmesine izin verirler. Güçlü saldırılar, ciddi hasar veren yavaş ama güçlü saldırılardır, ancak bunlara çok sık güvenmek Geralt'ı cezaya açık bırakabilir. Zayıf rakipler güçlü saldırıları savuşturamaz.
                            </p>
                            <p>
                            Geralt darbeleri savuşturma yeteneğine sahiptir. Saldırıları savuşturmak, bir miktar hasarı emebilen kolay bir savunma manevrasıdır. Geralt, bir düşman saldırısı ona çarpmadan hemen önce Siper düğmesine basarak karşı saldırı gerçekleştirebilir. Karşı saldırılar, düşmanların dengesini bozarak birkaç karşılık verilmesine izin verir. Karşı saldırı ve savuşturma, yakın dövüş silahları kullandıkları için insanlara ve insan olmayanlara karşı en etkilidir. Ancak, mızrak gibi iki elle kullanılan silahlar savuşturulamaz. Geralt, meşale gibi bir nesneyi sol elinde tutarken karşı saldırı yapamaz.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-5 mt-5">
                        <video loop src="../img/guides/fight.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip" autoplay></video>
                    </div>
               </div>
           </div>
           <div class="container">
           <div class="row mt-1">
                    <div class="col-md-7 pt-4">
                        <h2 class="border-bottom mx-1" id="at">Roach üstünde dövüş</h2>
                        <div class="yazi2">
                            <p>
                                Saldırı kombinasyonları mevcut değil. Bunun yerine, çok küçük hedefleri vurmayabilecek yavaş, güçlü tek vuruşlar yaparsınız. Bu saldırılar çok fazla hasar verir. Dört nala koşarken yapılan vuruşlar engellenemez.
                            </p>
                            <p>
                                At üstünde saldırı tuşuna basılı tutmak at üstünde vuruş isabetinin zor olacağı için gözde görülür düzeyde zamanı yavaşlatır saldırıyı yapmak bu efekti kaldırır.
                            </p>
                            <p>
                            Siz dövüşürken Roach korkar. Korku seviyesi bir korku çubuğu ile temsil edilir. Bu çubuk dolarsa, Roach ayağa kalkar ve sizi yere serer ve sizi yaya olarak savaşmaya devam etmeye zorlar. Ölümsüz düşmanlarla savaşırken korku çubuğu çok hızlı dolar. Roach üzerinde Axii işaretini kullanmak Korku çubuğunu boşaltır ve bu Roach üzerinde yapabileceğiniz tek işarettir. Roach'ı at gözlükleriyle donatmak, Roach'ın daha az korkmasını sağlar.
                            </p>
                        </div>
                        <h2 class="border-bottom mt-5" id="közler">Silahlar</h2>
                        <div class="yazi2">
                            <p>

                                Geralt'ın silah cephaneliği kılıçlar, baltalar, tatar yayları, bombalar ve büyülü büyüleri içerir.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mt-4 mr-5">
                        <img src="img/roach.png" class="img-fluid d-block mx-5"></img>
                    </div>
               </div>
           </div>
           <div class="container">
               <div class="row mt-3">
                   <div class="col-md-7 pt4">
                   <h2 class="border-bottom mx-1" id="kılıç">Kılıçlar</h2>
                        <div class="yazi2">
                            <p>
                                Witcher'lar iki tür bıçak kullanır: çelik kılıçlar ve gümüş kılıçlar. Çelik kılıçlar en çok sihirli olmayan hayvanlara, insanlara ve insan olmayanlara karşı etkilidir. Gümüş kılıçlar en çok canavarlara ve büyülü yaratıklara karşı etkilidir. Bir düşmanın canlılık çubuğunun rengi, onlara karşı hangi kılıç türünün daha etkili olduğunu gösterir. Çubuk kırmızıysa, çelik bir kılıç kullanın. Çubuk gümüş ise, gümüş bir kılıç kullanın.
                            </p>
                        </div>
                   </div>
                   <div class="col-md-2  mt-4">
                        <img src="img/zirael.png" class="img-fluid d-block mx-5"></img>
                    </div>
               </div>
           </div>
            <div class="container">
                <div class="row mt-1">
                    <div class="col-md-7 pt4">
                    <h2 class="border-bottom mx-1" id="arbalet">Arbalet</h2>
                        <div class="yazi2">
                            <p>
                            Arbaletler, uçan düşmanları yere sermek için menzilli tek elle kullanılan silahlardır. Yüzerken, dalış yaparken veya bir tekneyi kullanırken kullanılabilecek tek silah arbaletlerdir. At sırtında kullanılabilirler. Envanter panelinde arbalet ile hangi okları kullanacağınızı seçebilirsiniz. Bazı okların özel nitelikleri vardır. Karada arbaletler, kılıçlar veya işaretler kadar fazla hasar vermez ve bir silahtan daha çok bir araç olarak hizmet eder.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 ">
                        <img src="img/arbalet.png" class="img-fluid d-block mx-5 radius rounded-lg"></img>
                    </div>
                </div>
            </div>
       </section>
       
        
    <script>
        const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].play()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].pause()
                        }
                    )
                }
    </script>
    <?php
        include "../inc/footer.php";
    ?>