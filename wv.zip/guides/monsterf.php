    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <link rel="stylesheet" href="../css/wfront/stylesheet.css">
    <?php
        $sayfa="Canavar Avı";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
        <section class="ne text-white pt5">
            <div class="container">
            <h2 class="colordred text-center">Canavar Avı</h2>
                <div class="row mt-1">
                    <div class="col-md-7">
                        <div class="yazi">
                        <p class="text-center"> Canavar avı görevleri, isteğe bağlı sözleşmelerin yanı sıra ana hikayenin bir parçası olacak. Geralt, bu görevleri dünyanın dört bir yanındaki vatandaşlardan ve çeşitli kasabalarda bulunabilen duyuru panoları aracılığıyla kabul edebilir. Sözleşmeler Geralt'ı çeşitli ödüllerle ödüllendirecek.</p>
                        <p>
                            Yaratıkları izlemek için en iyi yöntem Geralt'ın Witcher duyularını kullanmaktır. Canavar saldırılarına tanık olan yoldan geçenlerle sohbet etmek, bir sonraki nereye bakılacağını bulmanın harika bir yolu olabilir. Geralt'ın Witcher Hissi, duyularını geliştirmesine ve izleri bulmasına izin veriyor. İster kan izi ister bir canavarın kokusu olsun, Witcher hissi Geralt'ın izlemesi için net bir görsel yol sağlar.
                        </p>
                        <p>
                            Düşmanını bilmek de düşmanını öldürmenin anahtarıdır. Oyun içi yaratık külliyatı, birkaç canavarın özelliklerini okumak için harika bir yoldur. Bazen Geralt, takip ettiği canavarla ilgili ayrıntılı ayrıntıları zaten biliyor. Diğer zamanlarda, ister sohbet ister kitaplar olsun, bilgileri başka yollarla keşfetmeniz gerekir. Hangi iksirlerin hazırlanacağını, hangi yağların uygulanacağını ve hangi silahların düşmanlarınıza karşı en etkili olduğunu keşfetmek kesinlikle çok önemlidir.
                        </p>
                        <p>
                            Son olarak, en önemli adım canavarın hamlelerini bilmektir. Bazen yaratığı kovalamanız gerekir, özellikle de ejder veya griffin gibi uçan bir türse. Doğrudan yüzleşme zor olabilir, ancak saldırı düzenlerini öğrenmek ve canavarlar üzerinde uygun boşluk bırakmak çok önemlidir. Ne zaman yakın veya uzak mesafeden saldırılacağını bilmek de önemlidir.
                        </p>
                        </div>
                    </div>
                    <div class="col-md-5">
                       <img src="img/mfight.jpg" class="mt-5 mx-auto img-fluid d-flex rounded-sm" width="100%" alt="">
                       <div class="pt-5">
                       <video loop src="../img/guides/monsterf.mp4" poster="../img/guides/monsterf.jpg" class="img-fluid d-block mx-auto radius rounded-lg clip" autoplay></video>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script>
        const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].play()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].pause()
                        }
                    )
                }
    </script>
    <?php
        include "../inc/footer.php";
    ?>