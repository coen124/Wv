<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Büyüler";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
       <section class="ne text-white pt-5">
           <div class="container">
               <div class="row mt-1">
                    <div class="col-md-7">
                    <h1 class="text-danger text-center ">İşaretler</h1>
                    <div class="container yazi ">
                      <p class="text-center pbosluk">
                        Witcher'lar, tehlikeli tehditleri savuşturmak için savaşta işaret adı verilen tek elle yapılan büyülerden yararlanır. Bu büyüler saldırı ve savunma amaçlı kullanılabilir ve savaşın gidişatını değiştirmeye yardımcı olabilir. Tehlikeli alevleri kanalize ederek, koruyucu bir kalkan ya da düşmanlarının zihinlerini kontrol ederek olsun, Geralt'ın sırtını asla duvara dayamaz.
                      </p>
                      <p>
                         Tüm işaretler,  dört kademeli yükseltmeye sahiptir. Bir sonraki kademenin kilidi, önceki kademedeki yükseltmelere yeterli yetenek puanı uygulandıktan sonra açılabilir. Yükseltmeler, değişen etkilerle 2-5 olası seviyeye sahip olabilir. Tüm işaret yükseltmeleri, savaşta +0.5/sn dayanıklılık yenilemesi ekler.
                      </p>
                      <p>
                        Tüm İşaretler için, Alternatif modunun kilidini açar ve slota eklerseniz, bunu, sadece ona dokunmak yerine İmza tuşuna basılı tutarak etkinleştirilirsiniz.
                      </p>
                      <div>
                      <img src="img/igni.jpg" class="img-fluid d-block mx-auto radius rounded-lg" ></img>
                      </div>
                    </div>
                    </div>
                    <div class="col-md-5 mt-5">
                        <h5 class="colordred ">İçindekiler</h5>
                        <ul>
                            <li>
                                <a href="#aard">Aard</a> 
                                <ul>
                                    <li class="lista2">
                                        <a href="#ay">Yükseltmeler</a>
                                    <ul>
                                            <li class="lista2">Uzağa erişen Aard </li>
                                            <li class="lista2">Aard Süpürmesi </li>
                                            <li class="lista2">Aard Şiddeti </li>
                                            <li class="lista2">Şok Dalgası </li>
                                    </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <a href="#igni">İgni</a> 
                                <ul>
                                    <li class="lista2">
                                        <a href="#igniy">Yükseltmeler</a>
                                    <ul>
                                            <li class="lista2">Zırh Eritme </li>
                                            <li class="lista2">Ateş akımı </li>
                                            <li class="lista2">İgni Şiddeti </li>
                                            <li class="lista2">PIROMAN </li>
                                    </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <a href="#yrden">Yrden</a> 
                                <ul>
                                    <li class="lista2">
                                        <a href="#yy">Yükseltmeler</a>
                                    <ul>
                                            <li class="lista2">Uzun süreli glifler</li>
                                            <li class="lista2">Büyü Tuzağı </li>
                                            <li class="lista2">Yrden Şiddeti </li>
                                            <li class="lista2">Aşırı Yüklü Glifler </li>
                                    </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <a href="#quen">Quen</a> 
                                <ul>
                                    <li class="lista2">
                                        <a href="#qy">Yükseltmeler</a>
                                    <ul>
                                            <li class="lista2">Patlayan Kalkan </li>
                                            <li class="lista2">Aktif Kalkan </li>
                                            <li class="lista2">Quen Şiddeti </li>
                                            <li class="lista2">Quen Boşaltımı </li>
                                    </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <a href="#axi">Axii</a> 
                                <ul>
                                    <li class="lista2">
                                        <a href="#axiy">Yükseltmeler</a>
                                    <ul>
                                            <li class="lista2">Kandırma </li>
                                            <li class="lista2">Kukla </li>
                                            <li class="lista2">Axi Şiddeti </li>
                                            <li class="lista2">Egemenlik </li>
                                    </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
               </div>
           </div>
           <div class="container">
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4" id="gb">
                            <h2 class="border-bottom text-info" id="aard">Aard</h2>
                            <div class="yazi mt-3">
                            <p>
                                Aard işareti, Witcherlar tarafından kullanılan basit bir büyülü işarettir. Rakipleri sersemleten ve onları sonraki bir saldırıya açık bırakan, yönlendirilmiş bir telekinetik enerji patlaması. "Bu işaret, rakipleri sarsabilen veya devirerek saldırıya açık bırakabilen, yönlendirilmiş bir telekinetik enerji dalgası gönderir. Aard ayrıca mevcut yangınları söndürebilir, güvenli olmayan kapıları patlatarak açabilir veya çatlamış veya hasar görmüş duvarları veya zeminleri delebilir.
                            </p>
                            <p> Bu becerinin ne kadar yararlı olabileceğini hafife almayın. Devrilen bazı düşmanlar, anında bir infaz tekniği ile bitirilebilir. Uçan düşmanlar da gökyüzünden fırlatılabilir ve bıçaklarınızın ulaşabileceği bir yere getirilebilir. Aard'ın düşmanları yere serme şansı ve yerde kaldıkları süre daha yüksek işaret yoğunluğuyla artar.</p>
                            <p>
                                Alternatif modu Aard Süpürmesi, Geralt'ın dalgayı aşağıya doğru ateşlemesini sağlar ve her yöne yayılır ve diğer tüm yükseltmeler onu etkilemeye devam eder. Uza Uzanan Aard ile bu, etrafınızdaki düşmanların geri çekilmesini sağlamak için nihai harekettir.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-3 ">
                        <img src="img/aard.jpg" class="img-fluid d-block mx-auto radius rounded-lg signslogo" width="90%"></img>
                        <video loop src="../img/guides/aard.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip mt-3" width="90%"></video>
                    </div>
               </div>
               <h5 class="colordred my-1 border-bottom" id="ay">Yükseltmeler</h5>
               <p class="yazi">Aşağıda, gerekli yükseltmeler yapılırsa ve slota eklenirse etki edeceği efektler listelenmiştir. Unutulmamalıdır ki kendinden bir önceki yetenekler tamamlamadan diğer yetenekler açılmaz.</p>
                <ul>     
                        <li class="yazi mt-1"><i class="colordred">Uzağa Erişen Aard --></i> Yükseltme başına aard menzilini 1 metre arttırır.</li>
                        <li class="yazi mt-1"><i class="colordred">Aard Süpürmesi--></i> Alternatif bir işaret modu açar. Aard dairesel bir alan içindeki herşeye isabet eder.</li>
                        <li class="yazi mt-1"><i class="colordred">Aard Şiddeti --></i> Yükseltme başına Aard vuruş hasarını %5 artırır (maks. %25).</li>
                        <li class="yazi mt-1"><i class="colordred">Şok Dalgası --></i> Aard yükseltme başına 40 puan ekstra hasar verir (maks. 200).</li>
                </ul>   
           </div>
           <div class="container">
           <h2 class="border-bottom text-danger pt-5" id="igni">İgni</h2>
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4" id="gb">
                            <div class="yazi mt-3">
                            <p>
                                Igni işareti, Witcherlar tarafından kullanılan basit bir büyülü işarettir. Rakipleri püskürtebilen ve ateşleyebilen ve ayrıca ateş başlatabilen bir pirokinetik patlamadan oluşur. "Ateşli Igni İşareti, Rivyalı Geraltın'nın düşmanlarına bir kor dalgası yaymasına izin veriyor. Ayrıca meşale veya kamp ateşi yakmak gibi daha incelikli bir şey için de kullanılabilir. Igni, ateşe karşı zayıf düşmanlara karşı inanılmaz derecede etkilidir. Düşmanları ateşe verebilir ve zamanla hasar verebilir.Bazı durumlarda, bu etki düşmanın paniklemesine neden olur.Ayrıca, havadaki herhangi bir yanıcı gaz, düşmanlarınıza zarar verebilecek ve onları sersemletebilecek güçlü patlamalara neden olmak için ateşlenebilir. İşaret Yoğunluğu ile ölçeklenir.
                            </p>
                            <p> Yanıcı gazları tutuşturma görevini olduğunu da unutmamak gerekir ne de olsa ateş, ateştir. Oyunda, genellikle bataklıklarda ve bazen de yeşil gazların yerden sızdığı dar zindan koridorlarında olmak üzere çeşitli alanlar var. Geralt bunların içlerinden geçerse bu Geralt için çok zehirlidir. Yükseltilmemiş bir İgni, hareket etmeniz için güvenli bir yol açmak üzere gazları güvenli bir şekilde patlatmak için yeterli menzile sahiptir, bu da bölgeden zarar görmeden yavaş ama emin bir şekilde geçmenizi sağlar. Bununla birlikte, yerden gaz sızan çoğu alanın yaklaşık 10 saniye sonra tekrar gaz sızdırmaya yeniden başlayacağı konusunda uyarılmalıdır, bu nedenle alandan çıkana kadar hareket etmeye devam ettiğinizden emin olun.</p>
                            <p>
                            Alternatif modu Ateşakımı, Geralt'ın parmaklarından sürekli olarak dar bir ateşli kıvılcım akışı bırakmasını sağlar. Normal bir Igni'den daha az olsa da zamanla hasar verir.Ateşakımı kalkanlarla donatılmış rakiplere karşı kullanmak, birkaç saniye sonra o kalkanın yanmasına ve rakibin saldırıya açık kalmasına neden olur.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-3 ">
                        <img src="img/igni2.png" class="img-fluid d-block mx-auto radius rounded-lg signslogo" width="90%"></img>
                        <video loop src="../img/guides/igni.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip mt-3" width="90%"></video>
                    </div>
               </div>
               <h5 class="colordred my-1 border-bottom" id="igniy">Yükseltmeler</h5>
               <p class="yazi">Aşağıda, gerekli yükseltmeler yapılırsa ve slota eklenirse etki edeceği efektler listelenmiştir. Unutulmamalıdır ki kendinden bir önceki yetenekler tamamlamadan diğer yetenekler açılmaz.</p>
                <ul>     
                        <li class="yazi mt-1"><i class="colordred">Zırh Eritme --></i>Yükseltme başına, İgni tarafından verilen hasar düşmanın zırhını zayıflatır, İgninin vermiş olduğu hasarı %15 arttırır (maks. %75).</li>
                        <li class="yazi mt-1"><i class="colordred">Ateş akımı--></i> Alternatif bir işaret modu açar. Düşmanlara hasar veren sürekli bir ateş akımı çıkarır</li>
                        <li class="yazi mt-1"><i class="colordred">İgni Şiddeti --></i> Yükseltme başına İgni vuruş hasarını %5 artırır (maks. %25).</li>
                        <li class="yazi mt-1"><i class="colordred">PIROMAN --></i>Yanma etkisi uygulama olasığı %20 artar. (maks. %100).</li>
                </ul>   
           </div>
           <div class="container">
           <h2 class="border-bottom text-purple pt-5" id="yrden">Yrden</h2>
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4">
                            <div class="yazi mt-3">
                            <p>
                                Yrden işareti, Witcherlar tarafından kullanılan basit bir büyülü işarettir. Yerde, bir düşman tarafından geçildiğinde sınırlı sayıda tetiklenen ve geri tepmeye, hasara ve durum rahatsızlıklarına neden olma şansına neden olan büyülü bir tuzak oluşturur. "Bu İşareti kullandıktan sonra Geralt'ın etrafında bir Yrden sembolleri çemberi belirir. O çemberin içine giren çoğu düşman önemli ölçüde yavaşlar, ancak bazı canavarlar bundan etkilenmez.
                            </p>
                            <p>
                                Çember, yakın muharebe menzilindeki birden fazla düşmanı kontrol etmek için emrinizde olan en iyi araçlardan biridir. Yrden, Noonwraith ve Nightwraith'e karşı paha biçilmezdir. bir Yrden çemberine yakalanmadıkça çoğu zaman cisimsiz kalırlar. Yrden rakipleri yavaşlatma yeteneği, işaret yoğunluğu ile artar"
                            </p>
                            <p>
                                Alternatif modu Büyü Tuzağı, 10 metre içindeki düşmanları otomatik hedefleyip onlara hasar veren bir tuzak oluşturur.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-3 ">
                        <img src="img/yrden.png" class="img-fluid d-block mx-auto radius rounded-lg signslogo" width="90%"></img>
                        <video loop src="../img/guides/yrden.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip mt-3" width="90%"></video>
                    </div>
               </div>
               <h5 class="colordred my-1 border-bottom" id="yy">Yükseltmeler</h5>
               <p class="yazi">Aşağıda, gerekli yükseltmeler yapılırsa ve slota eklenirse etki edeceği efektler listelenmiştir. Unutulmamalıdır ki kendinden bir önceki yetenekler tamamlamadan diğer yetenekler açılmaz.</p>
                <ul>     
                        <li class="yazi mt-1"><i class="colordred">Uzun Süreli glifler --></i>.İşaret süresini 10sn arttırır.</li>
                        <li class="yazi mt-1"><i class="colordred">Büyü Tuzağı--></i> Alternatif bir işaret modu açar. 10 metre içindeki düşmanları otomatik hedefleyip onlara hasar veren bir tuzak oluşturur.</li>
                        <li class="yazi mt-1"><i class="colordred">Yrden Şiddeti --></i> Yükseltme başına Yrden işaret şiddetini %5 artırır (maks. %25).</li>
                        <li class="yazi mt-1"><i class="colordred">Aşırı Yüklü Glifler --></i>Yrden etkisi altında rakipler her saniye 10 can ve öz kaybeder (maks. 50).</li>
                </ul>   
           </div>
           <div class="container">
           <h2 class="border-bottom text-warning pt-5" id="quen">Quen</h2>
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4">
                            <div class="yazi mt-3">
                            <p> 
                                Quen işareti, Witcherlar tarafından kullanılan basit bir büyülü işarettir. Aktifleştirildiğinde, Witcher'ın etrafında koruyucu bir alan oluşturur. Bu işaret, yaşam ve ölüm arasındaki fark olabilir. Quen'in temel yeteneği, sınırlı miktarda hasarı emen temel bir kalkanla Geralt'ı korumaktır.
                            </p>
                            <p>
                                Genellikle bu, çoğu eşit seviyedeki düşmana karşı tek bir vuruş anlamına gelir, ancak bu Quen'in kullanışlı olmadığı anlamına gelmez. Hafif Zırh kullanıyorsanız, Dayanıklılık yenilenmeniz o kadar hızlı olabilir ki, bir dövüşte Quen'i birden çok kez kullanabilirsiniz, bu da sizi hasardan korur. Quen'e yatırım yapmak, kırılmadan önce birkaç vuruşu sürdürebilmesini sağlayabilir. Bu, İşaret Yoğunluğu ile ölçeklenir.
                            </p>
                            <p>
                                Alternatif mod, Aktif Kalkan, İşaret tuşunu basılı tuttuğunuz sürece Geralt'ın çevresinde görünür sarı kubbeli bir kuvvet alanı oluşturur, 3. seviyede sahip değilseniz veya düşmanlar onu kırarsa Dayanıklılığı biter. Aktif Kalkan açıkken hiçbir şekilde saldıramazsınız, ancak yine de yavaş bir yürüyüşle hareket edebilirsiniz. Düşman vuruşları, kendi sağlığınızı oldukça büyük ölçüde yeniler.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-3 ">
                        <img src="img/quen.png" class="img-fluid d-block mx-auto radius rounded-lg signslogo" width="70%"></img>
                        <video loop src="../img/guides/quen.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip mt-3" width="70%"></video>
                    </div>
               </div>
               <h5 class="colordred my-1 border-bottom" id="qy">Yükseltmeler</h5>
               <p class="yazi">Aşağıda, gerekli yükseltmeler yapılırsa ve slota eklenirse etki edeceği efektler listelenmiştir. Unutulmamalıdır ki kendinden bir önceki yetenekler tamamlamadan diğer yetenekler açılmaz.</p>
                <ul>     
                        <li class="yazi mt-1"><i class="colordred">Patlayan Kalkan --></i>Quen kırıldığında patlayarak düşmanları sendeletir.</li>
                        <li class="yazi mt-1"><i class="colordred">Aktif Kalkan--></i> Alternatif bir işaret modu açar. Aktif bir kalkan oluşturur, dayanıklılık tüketir, emilen hasar canı tazeler.</li>
                        <li class="yazi mt-1"><i class="colordred">Quen Şiddeti --></i> Yükseltme başına Quen işaret şiddetini %5 artırır (maks. %25).</li>
                        <li class="yazi mt-1"><i class="colordred">Quen Boşaltımı --></i>Emilen hasarın %5 kadarını salırgana yansıtır (maks. %25).</li>
                </ul>   
           </div>
           <div class="container">
           <h2 class="border-bottom text-success pt-5" id="axi">Axii</h2>
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4">
                            <div class="yazi mt-3">
                            <p>
                                Axii işareti, Witcherlar tarafından kullanılan basit bir büyülü işarettir. Bu, bir düşmanın Witcher'ın yanında savaşmasına neden olan bir altıgeni tetikleyen zihinsel bir dalgadır. Efekt zamanla aşınabilir veya Witcher'ın verdiği hasarla bozulabilir. "Bu işaret, bir rakibin zihnini bulandırarak, onları geçici olarak savaştan çıkarmayı mümkün kılar. İnsanlara karşı en etkili olanıdır, ancak belirli canavarlar üzerinde de çalışabilir. Özellikle zahmetli görünen bir düşmanı hedefleyin, ardından Axii'yi kullanın. Onlarla başa çıkmaya hazır olana kadar onları savaşın dışında bırakın.
                            </p>
                            <p>
                                Axii, bazı durumlarda diğer karakterlerle konuşmalarda da kullanılabilir, ancak bazı insanlar güçlü iradeye sahiptir ve buna direnebilir. İlgili yeteneğine Yetenek Puanları yatırarak bundan kaçının. Bu, yeni seçenekler açar ve yalnızca bir tehdidin geçici olarak ortadan kaldırılmasıyla devam eden mücadeleyi kolaylaştırmakla kalmaz, sorunu daha barışçıl bir şekilde çözebilir.
                            </p>
                            <p>
                                Alternatif modu Kukla, Hedeflenen düşman kısa süreliğine bir müttefik olur ve seviye başına %20 daha fazla hasar verir.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-3 ">
                        <img src="img/axi.png" class="img-fluid d-block mx-auto radius rounded-lg signslogo" width="90%"></img>
                        <video loop src="../img/guides/axi.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip mt-3" width="90%"></video>
                    </div>
               </div>
               <h5 class="colordred my-1 border-bottom" id="axiy">Yükseltmeler</h5>
               <p class="yazi">Aşağıda, gerekli yükseltmeler yapılırsa ve slota eklenirse etki edeceği efektler listelenmiştir. Unutulmamalıdır ki kendinden bir önceki yetenekler tamamlamadan diğer yetenekler açılmaz.</p>
                <ul>     
                        <li class="yazi mt-1"><i class="colordred">Kandırma --></i>Diyaloglarda axinin etkinliğini arttırır. Yetenek puanı vermek güçlü iradelileri de etkileyebilmeye yarar.</li>
                        <li class="yazi mt-1"><i class="colordred">Kukla--></i>Hedeflenen düşman kısa süreliğine bir müttefik olur ve seviye başına %20 daha fazla hasar verir.</li>
                        <li class="yazi mt-1"><i class="colordred">Axii Şiddeti --></i> Yükseltme başına Axii işaret şiddetini %5 artırır (maks. %25).</li>
                        <li class="yazi mt-1"><i class="colordred">Egemenlik --></i>Aynı anda iki düşman birden Axii'den etkilenebilir.</li>
                </ul>   
           </div>
       </section>
    <script>
        const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].pause()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].play()
                        }
                    )
                }
    </script>
    <?php
        include "../inc/footer.php";
    ?>