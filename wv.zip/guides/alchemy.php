<link rel="stylesheet" href="../css/wfont/stylesheet.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/mystyles.css">
    <?php
        $sayfa="Simya";
        $sekme="icice"; 
        include "../inc/baglanti.php";
        include "../inc/header.php";
    ?>
       <section class="ne text-white pt-5">
           <div class="container">
               <div class="row mt-1">
                    <div class="col-md-7">
                    <h1 class="text-danger text-center ">Simya</h1>
                    <div class="container yazi ">
                      <p class="text-center pbosluk">
                      Simya Kılavuzumuzda güçlü tariflerin yanı sıra Simya'nın tüm güçlü yönlerini keşfedin.
                      </p>
                      <p>
                      Witcher serisinde, simya çalışması, savaşlara avantaj sağlayabilecek güçlü saldırı ve savunma karışımları yaratabilir. Simya sadece witcherlar tarafından değil, aynı zamanda dünya nüfusunun önemli bir kısmı tarafından da kullanılıyor. Geralt otları, canavar parçalarını ve diğer malzemeleri sentezleyerek savaş etkinliğini artırabilir. Simyanın en büyük gücü, gerekli olan dövüş stiliyle eşleşmek için belirli bir statü veya yeteneği artırarak oyuncuya belirli bir karşılaşmada avantaj sağlamasıdır. Oyuncular iksir, yağ ve bomba yapabilirler.
                      </p>
                    </div>
                    </div>
                    <div class="col-md-5 mt-5">
                        <h5 class="colordred ">İçindekiler</h5>
                        <ul>
                            <li>
                                <a href="#gb">Genel Bilgi</a> 
                                <ul>
                                    <li><a href="#iksirler">İksirler</a> </li>
                                    <li><a href="#közler">Kaynatılmış Özler</a> </li>
                                    <li><a href="#KY">Kılıç yağları</a> </li>
                                    <li><a href="#bombalar">Bombalar</a> </li>
                                </ul>
                                <li>
                                    <a href="#listea">İksir/Kaynatılmış öz Listesi</a>
                                    <ul>
                                        <li><a href="#genel">Genel iksirler/özler</a></li>
                                        <li><a href="#iöz">iyileştirici İksirler/özler</a></li>
                                        <li><a href="#döz">Defansif İksirler/özler</a></li>
                                        <li><a href="#oöz">Agrasif İksirler/özler</a></li>
                                    </ul>
                                </li>
                            </li>
                        </ul>
                    </div>
               </div>
           </div>
           <div class="container">
               <div class="row mt-1">
                   <div class="col-md-7">
                        <div class="pt-4" id="gb">
                            <h2 class="border-bottom">Genel Bilgi</h2>
                            <div class="yazi mt-3">
                            <p>
                            The Witcher 3: Wild Hunt'ta iksirler, bombalar ve silah yağları, oyuncuların seyahatlerinde bulacakları malzemelerden üretilmiştir. Daha az, daha yaygın mutajenler de güçlerini artırmak için birleştirilebilir.
                            </p>
                            <p>
                            Bir simyasal madde veya bileşik ürettiğinde, Geralt, envanterinde güçlü alkol (veya başka bir gerekli malzeme) bulunması koşuluyla, meditasyon sırasında doldurulabilecek her birinin sınırlı bir tedarikini elinde tutar. Meditasyonda iksirlerin yenilenmesi için kullanılan varsayılan bileşem alkoldür; Bu mümkün değilse, başka bir alkol türü kullanılacaktır. Eldeki tedarik limiti, daha yüksek seviyeli formüller bularak (örneğin, geliştirilmiş veya üstün versiyonlar) veya simya dalında ilgili karakter yükseltmelerini seçerek arttırılabilir.
                            </p>
                            </div>
                      </div>
                   </div>
                    <div class="col-md-5 mt-5">
                        <video loop src="../img/guides/alchemy.mp4" class="img-fluid d-block mx-auto radius rounded-lg clip" autoplay></video>
                    </div>
               </div>
           </div>
           <div class="container">
           <div class="row mt-1">
                    <div class="col-md-7 pt-4">
                        <h2 class="border-bottom mx-1" id="iksirler">İksirler</h2>
                        <div class="yazi2">
                            <p>
                            İksir yapmak için bir tarif, bir temel ham madde (genellikle alkol) ve yolculuk boyunca elde edilebilecek başka eşyalar gerekir. Tüketildiğinde, iksirler Geralt'ın toksisitesini arttırır, bu nedenle mevcut istatistiklerine göre yalnızca belirli bir miktarı tüketebilir. Herşeyin fazlası zarardır.
                            </p>
                        </div>
                        <h2 class="border-bottom mt-5" id="közler">Kaynatılmış Özler</h2>
                        <div class="yazi2">
                            <p>
                                Kaynatılmış özler, iksirlerin özel ve daha güçlü bir alt türüdür. Aynı şekilde hazırlanmışlardır, yani bir simya formülüne ve diğer çeşitli kaynaklara ihtiyaç duyarlar ve Geralt meditasyon yaptığında yenilenirler. Ancak, birkaç önemli farklılık vardır. İlk olarak, tarifler çok daha nadirdir. İkincisi, bir kaynatılmış öz için gerekli bileşenlerden biri, elde edilmesi son derece zor olabilen nadir bir canavarın mutajeni olabilir. Üçüncüsü, bunlar açık ara en güçlü iksirlerdir. Etkileri varsayılan olarak tam 30 dakika sürer (96 dakika süren Basilisk özü hariç).
                            </p>
                            <p>
                                 Özler kullanıldığında Toksisiteye +70 puan verir (+40 veren Basilisk özü hariç), normal iksirlerden çok daha yüksektir ve etkileri son derece güçlüdür. Meditasyonlar arasında ortalama olarak 3 kullanımlık bir stoğa sahip olan normal iksirlerin aksine, özler yalnızca bir stoğa sahiptir.

                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mt-4">
                        <img src="img/asdjlkkashd.png" class="img-fluid d-block mx-5"></img>
                    </div>
               </div>
           </div>
           <div class="container">
               <div class="row mt-1">
                   <div class="col-md-7 pt4">
                   <h2 class="border-bottom mx-1" id="KY">Kılıç Yağları</h2>
                        <div class="yazi2">
                            <p>
                                Geralt'ın üretebileceği veya satın alabileceği üç simya aracından en kullanışlı simya aracı olabilir, ancak aynı şekilde daha fazla planlama ve malzeme gerektirir. Düşman hakkında bilgi, kılıç yağlarının avantajlarını en üst düzeye çıkarmanın anahtarıdır.
                            </p>
                            <p>
                                Yağlar, kılıçları kaplamak için kullanılır ve böylece Geralt'ın hedef aldığı belirli düşman için hasar derecesini artırır. Etkiler yalnızca başarılı bir vuruştan sonra görülür.
                            </p>
                            <p>
                                 Bir kez uygulandığında, silah yağları rakibe sınırlı sayıda isabet sağlar. 20 vuruş temel yağ tipi, 40 vuruş geliştirilmiş tip, 60 vuruş üstün yağ tipi içindir. Duruma göre farklı yağlar uygulanabilir. Farklı bir yağ uygulamak, eski yağın silah üzerindeki etkisini ortadan kaldırır.
                            </p>
                            <p>
                                Yağların verdiği hasar artışı da aralarındaki ölçekte aynıdır, tek fark etkilenen canavar türleridir. Temel yağlar %10, geliştirilmiş yağlar %25 ve üstün yağlar %50 isabet halinde hasar artışı sağlar.
                            </p>
                            <p>
                                Yağ üretmek için bir tarif, bir temel madde (genellikle bir yağ veya içyağı) ve yolculuk boyunca elde edilebilecek başka eşyalar gerekir. Yağlar, bombaların veya iksirlerin aksine asla tükenmez veya yenilenmeye ihtiyaç duymaz.
                            </p>
                        </div>
                   </div>
                   <div class="col-md-4 mt-4">
                        <img src="img/yaglar.png" class="img-fluid d-block mx-4"></img>
                    </div>
               </div>
           </div>
            <div class="container">
                <div class="row mt-1">
                    <div class="col-md-7 pt4">
                    <h2 class="border-bottom mx-1" id="bombalar">Bombalar</h2>
                        <div class="yazi2">
                            <p>
                                Bombalar, kalabalıklaşmış düşman gruplarına hasar verebilen, sersemleten veya başka etkilere neden olabilen, alanı etkileyen, fırlatılan nesnelerdir. Bir canavar yuvasını witcher bombaları ile yok edebilirsiniz.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mt-4">
                        <img src="img/bombs.png" class="img-fluid d-block mx-5"></img>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row mt-1">
                    <div class="col-md-12 pt4">
                    <h2 class="border-bottom mx-1" id="listea">İksir ve kaynatılmış öz Listesi</h2>
                        <div class="yazi2">
                            <p>
                            Oyundaki iksir ve Kaynatılmış öz sayısının çok büyük olduğu ve menü ekranlarında gösterilen tarif sayfalarının efektlerini değil sadece tarifin adını gösterdiği ve oyun içi Simya menüsünün bile gerçek sayıları göstermediği için efektlerin gerçekte ne yaptığını görmeniz için bu bölüme göz atabilirsiniz. Çeşitli tariflerin bir listesi ve kısa efekt açıklamaları aşağıda İyileştirici, ofansif ve defansif olarak gruplara ayrılmış olarak verilecektir.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-5">
                <h5 class="colordred my-1 border-bottom" id="genel">Genel</h5>
                <p class="yazi">Aşağıdakiler, Geralt üzerinde doğrudan savaşla ilgili olmayan ama genel olarak kullanışlı iksirler/özlerdir.</p>
                <ul>
                    <?php
                        $sorgu=$db->prepare("select * from iksirler where iksirkategori=1");
                        $sorgu->execute();

                        while ($sonuc=$sorgu->fetch()) {
                            ?>
                        <li class="yazi mt-1"><img src="img/<?=$sonuc['iksirfoto']?>"><i class="colordred"><?=$sonuc['iksirad']." --> "?> </i><?=$sonuc['iksirbuff']?></li>
                    <?php
                        }
                    ?>
                </ul>   
                <h5 class="colordred border-bottom mt-5" id="iöz">İyileştirici</h5>
                <p class="yazi">
                    Aşağıdakiler, Geralt'taki hasarı, Sağlığı geri kazandıran veya zehir gibi olumsuz etkileri ortadan kaldırarak bir şekilde onaran veya dövüş dışı farklı efektler iksirler ve kaynatılmış özlerdir.</p>
                <ul>        
                <?php
                        $sorgu2=$db->prepare("select * from iksirler where iksirkategori=2");
                        $sorgu2->execute();

                        while ($sonuc2=$sorgu2->fetch()) {
                            ?>
                        <li class="yazi mt-1"><img src="img/<?=$sonuc2['iksirfoto']?>"><i class="colordred"><?=$sonuc2['iksirad']." --> "?> </i><?=$sonuc2['iksirbuff']?></li>
                    <?php
                        }
                    ?>
                </ul>
                <h5 class="colordred border-bottom mt-5" id="döz">Defansif</h5>
                <p class="yazi">Aşağıdakiler, Geralt'ı hasardan veya olumsuz durum etkilerinden koruyan iksirler ve özlerdir.</p>
                <ul>        
                <?php
                        $sorgu2=$db->prepare("select * from iksirler where iksirkategori=3");
                        $sorgu2->execute();

                        while ($sonuc2=$sorgu2->fetch()) {
                            ?>
                        <li class="yazi mt-1"><img src="img/<?=$sonuc2['iksirfoto']?>"><i class="colordred"><?=$sonuc2['iksirad']." --> "?> </i><?=$sonuc2['iksirbuff']?></li>
                    <?php
                        }
                    ?>
                </ul>
                <h5 class="colordred border-bottom mt-5" id="oöz">Agrasif</h5>
                <p class="yazi">Aşağıdakiler, Geralt'ın bir şekilde düşmanlara verebileceği hasarı artıran iksirler ve özlerdir (yağlar değil).</p>
                <ul>        
                <?php
                        $sorgu2=$db->prepare("select * from iksirler where iksirkategori=4");
                        $sorgu2->execute();

                        while ($sonuc2=$sorgu2->fetch()) {
                            ?>
                        <li class="yazi mt-1"><img src="img/<?=$sonuc2['iksirfoto']?>"><i class="colordred"><?=$sonuc2['iksirad']." --> "?> </i><?=$sonuc2['iksirbuff']?></li>
                    <?php
                        }
                    ?>
                </ul>
            </div>
       </section>
       
        
    <script>
        const clip = document.querySelectorAll('.clip');
                for (let i = 0; i < clip.length; i++) {
                    clip[i].addEventListener('mouseenter',

                        function (e) {
                            clip[i].pause()

                        }
                    )
                    clip[i].addEventListener('mouseout',
                        function (e) {
                            clip[i].play()
                        }
                    )
                }
    </script>
    <?php
        include "../inc/footer.php";
    ?>